# Get Started

## Before You Begin
1. Make sure you have installed Node.js v16.13.0, PostgreSQL. (Required)
2. Install Node Version Manager to Make it easy to Switch Different Node Versions (Recommended) 
3. Install UFW and Control ports who can access

## Setup Offerwall
* Wannads
1. Go wannads.com and login to your publisher account
2. Click "Create New App"
3. Configure settings as follows:<br>
App URL: [Your Top Page URL] <br>
App Type: Custom Web <br>
Currency name: Points <br>
Currency value: 500 <br>
Postback URL: [Your URL]/api/offerwalls/wannads <br>

* CPX Research
1. Go cpx-research.com and login to your publisher account
2. Click "Apps" > "Add new App"
3. Configure settings as follows:<br>
General Settings > Test Mode: inactive <br>
General Settings > Main platform: web <br>
Reward Settings > currency name: points <br>
Reward Settings > Currency Factor: $ 1  is 500 points <br>
Reward Settings > Currency Factor for Bonus: $1 is 1000 points <br>
Postback Settings > Main postback URL: [Your URL]/api/offerwalls/cpx?status={status}&trans_id={trans_id}&user_id={user_id}&amount_local={amount_local}&hash={secure_hash}&ip_click={ip_click} <br>

* Kiwiwall
1. Go kiwiwall.com and login to your publisher account
2. Click "New App"
3. Configure settings as follows:<br>
The type of your app: Reward <br>
Currency name: Points <br>
platform: web <br>
Exchange rate: 500 <br>
Postback URL: [Your URL]/api/offerwalls/kiwiwall <br>
App URL: [Your URL] <br>

* MediumPath
1. Go mediumpath.com and login to your publisher account
2. Click "Apps" > "Submit new app"
3. Configure settings as follows:<br><br>
App type: Web Offerwall <br>
Percentage of your users earning: 0.50 <br>
Offerwall virtual currency: Points <br>
Offerwall virtual currency multiplier: 1000 <br>
Postback URL: [Your URL]/api/offerwalls/mediumpath <br>
Offers Category: All <br>

* Bitlabs
1. Go bitlabs.ai and login to your publisher account
2. Click "New App"
3. Configure settings as follows:<br>
Mode: Offerwall <br>
Currency > text: Points <br>
Currency > Exchange Rate: 500 <br>
Implementation > Reward Callback URL: [Your URL]/api/offerwalls/bitlabs <br>
Implementation > Callback Parameter: <br>
    val - reward value <br>
    uid - unique user id (uid) <br>
    txid - transaction ID (tx) <br>

* Lootably
1. Go lootably.com and login to your publisher account
2. Click "New App /placement"
3. Configure settings as follows:<br>
Platform: Desktop/Mobile Web<br>
WebsiteURL: [Your URL]<br>
Currency > CurrencyName: Points<br>
Currency > Currency Conversion Rate: 500<br>
Postback > Postback URL: [Your URL]/api/offerwalls/lootably?userID={userID}&transactionID={transactionID}&ip={ip}&revenue={revenue}&currencyReward={currencyReward}&status={status}&hash={hash}<br>
Maximum Postback Retries: 5<br>

* Opinion Capital
1. Go publishers.opinioncapital.com and login to your publisher account
2. Click "Apps" > "Create"
3. Configure settings as follows: <br>
Iframe Reward Name: Points<br>
Iframe Reward Multiplier: 1000 <br>
Iframe Reward Ratio: 50<br>
Use Points: true<br>
Postback Settings > Survey Postback URL: [Your URL]/api/offerwalls/opinioncapital?payout=%PAYOUT%&hash=%HASH%&clickid=%CLICKID%&username=%USERNAME%&offernumber=%OFFERNUMBER%&status=%STATUS%&usereward=%USER_REWARD% <br>
Postback Settings > Offer Postback URL: [Your URL]/api/offerwalls/opinioncapital?payout=%PAYOUT%&hash=%HASH%&clickid=%CLICKID%&username=%USERNAME%&offernumber=%OFFERNUMBER%&status=%STATUS%&usereward=%USER_REWARD%<br>
Postback Hash Secret: [ Random ]<br>
Send Complete Notification: true<br>
Send Reversal Notification: true<br>


## Setup Sentry
1. Navigate to your sentry dashboard
2. Create New App
3. Select Javascript
4. Copy DSN URL and Save it for config.json


** Make sure your sentry DSN is correct ** 

## Edit the configuration

1. You need to clone the config.example.json file and to rename it to config.json
2. You need to clone the .env.example file and to rename it to .env
3. You will then have to complete it with your informations.

## Install dependencies
1. Run `npm i` to install all dependencies

## Deploy Database
1. Run `npx prisma migrate deploy` to deploy the database onto your PostgreSQL Database
2. Run `npx prisma generate` to Generate own ORM Client

## Build Typescript
1. Run ` npm run setup ` to convert the typescript files into JS files


# PM2
1. Run `npm i -g pm2` as the root user
2. Run `pm2 startup` to enable startup
3. Run `pm2 start pm2apps.json` to run the DropGC.
4. Enjoy it!

## Links

How To Install PostgreSQL on Ubuntu 20.04
https://www.digitalocean.com/community/tutorials/how-to-install-postgresql-on-ubuntu-20-04-quickstart

