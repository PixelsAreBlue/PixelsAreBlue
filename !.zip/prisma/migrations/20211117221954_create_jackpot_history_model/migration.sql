-- CreateTable
CREATE TABLE "JackpotHistory" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "points" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "JackpotHistory_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "JackpotHistory" ADD CONSTRAINT "JackpotHistory_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;
