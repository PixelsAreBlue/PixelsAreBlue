/*
  Warnings:

  - The values [pending,approved] on the enum `RewardOrderStatus` will be removed. If these variants are still used in the database, this will fail.

*/
-- CreateEnum
CREATE TYPE "DeliveryMethod" AS ENUM ('url', 'giftcode', 'direct');

-- AlterEnum
BEGIN;
CREATE TYPE "RewardOrderStatus_new" AS ENUM ('onHold', 'completed', 'refunded', 'rejected');
ALTER TABLE "RewardOrder" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "RewardOrder" ALTER COLUMN "status" TYPE "RewardOrderStatus_new" USING ("status"::text::"RewardOrderStatus_new");
ALTER TYPE "RewardOrderStatus" RENAME TO "RewardOrderStatus_old";
ALTER TYPE "RewardOrderStatus_new" RENAME TO "RewardOrderStatus";
DROP TYPE "RewardOrderStatus_old";
ALTER TABLE "RewardOrder" ALTER COLUMN "status" SET DEFAULT 'onHold';
COMMIT;

-- AlterTable
ALTER TABLE "RewardOrder" ADD COLUMN     "deliveryMethod" "DeliveryMethod",
ALTER COLUMN "status" SET DEFAULT E'onHold';
