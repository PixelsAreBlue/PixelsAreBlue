-- AlterTable
ALTER TABLE "User" ADD COLUMN     "newUnconfirmedEmail" TEXT;
