/*
  Warnings:

  - You are about to drop the `PtcCampaign` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `PtcHistory` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "PtcCampaign" DROP CONSTRAINT "PtcCampaign_username_fkey";

-- DropForeignKey
ALTER TABLE "PtcHistory" DROP CONSTRAINT "PtcHistory_campaignId_fkey";

-- DropForeignKey
ALTER TABLE "PtcHistory" DROP CONSTRAINT "PtcHistory_username_fkey";

-- DropTable
DROP TABLE "PtcCampaign";

-- DropTable
DROP TABLE "PtcHistory";
