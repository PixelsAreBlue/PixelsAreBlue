-- AlterTable
ALTER TABLE "webhookQueue" ADD COLUMN     "isError" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "rateLimitUntil" TIMESTAMP(3);
