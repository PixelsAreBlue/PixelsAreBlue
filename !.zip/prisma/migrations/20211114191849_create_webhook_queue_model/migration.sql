-- CreateTable
CREATE TABLE "webhookQueue" (
    "id" SERIAL NOT NULL,
    "webhookUrl" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL,
    "fields" JSONB NOT NULL,
    "isSent" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "webhookQueue_pkey" PRIMARY KEY ("id")
);
