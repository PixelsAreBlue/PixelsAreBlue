-- CreateEnum
CREATE TYPE "logLevel" AS ENUM ('debug', 'info', 'warn', 'error', 'fatal');

-- CreateEnum
CREATE TYPE "actionType" AS ENUM ('create', 'read', 'update', 'delete');

-- CreateEnum
CREATE TYPE "PtcPayment" AS ENUM ('bitcoin');

-- CreateEnum
CREATE TYPE "PtcStatus" AS ENUM ('unpaid', 'active', 'ended');

-- CreateEnum
CREATE TYPE "PtcTimer" AS ENUM ('s10', 's30', 's60', 's120');

-- CreateEnum
CREATE TYPE "RewardOrderStatus" AS ENUM ('pending', 'approved', 'rejected');

-- CreateEnum
CREATE TYPE "OfferAction" AS ENUM ('credit', 'reversal');

-- CreateEnum
CREATE TYPE "ReferCreditType" AS ENUM ('offer');

-- CreateTable
CREATE TABLE "session" (
    "sid" TEXT NOT NULL,
    "sess" JSONB NOT NULL,
    "expire" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "session_pkey" PRIMARY KEY ("sid")
);

-- CreateTable
CREATE TABLE "User" (
    "username" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "balance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "referrer" TEXT,
    "authCode" TEXT,
    "isAdmin" BOOLEAN NOT NULL DEFAULT false,
    "isBanned" BOOLEAN NOT NULL DEFAULT false,
    "isEmailVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("username")
);

-- CreateTable
CREATE TABLE "LoginLog" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "os" TEXT NOT NULL,
    "browser" TEXT NOT NULL,
    "device" TEXT NOT NULL,
    "ip" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LoginLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "referenceID" SERIAL NOT NULL,
    "logLevel" "logLevel" NOT NULL,
    "resourceName" TEXT NOT NULL,
    "eventName" TEXT NOT NULL,
    "description" TEXT,
    "actionInfo" TEXT NOT NULL,
    "actionType" "actionType" NOT NULL,
    "user" TEXT,
    "ip" TEXT,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("referenceID")
);

-- CreateTable
CREATE TABLE "PromotionHistory" (
    "id" SERIAL NOT NULL,
    "promotionName" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "points" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PromotionHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PromoCode" (
    "code" TEXT NOT NULL,
    "points" DOUBLE PRECISION NOT NULL,
    "maxUse" INTEGER,
    "expiryDate" TIMESTAMP(3),
    "isExpired" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PromoCode_pkey" PRIMARY KEY ("code")
);

-- CreateTable
CREATE TABLE "PromoCodeHistory" (
    "id" SERIAL NOT NULL,
    "code" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PromoCodeHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PtcCampaign" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "status" "PtcStatus" NOT NULL DEFAULT E'unpaid',
    "title" TEXT NOT NULL,
    "timer" "PtcTimer" NOT NULL,
    "maxClicks" INTEGER NOT NULL,
    "totalCostUsd" DOUBLE PRECISION NOT NULL,
    "rewardPoint" DOUBLE PRECISION NOT NULL,
    "url" TEXT NOT NULL,
    "paymentMethod" "PtcPayment" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PtcCampaign_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PtcHistory" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "campaignId" INTEGER NOT NULL,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PtcHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RewardCatalog" (
    "id" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "bannerImgUrl" TEXT,
    "customField" TEXT,
    "customFieldDescription" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RewardCatalog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RewardItem" (
    "id" SERIAL NOT NULL,
    "catalogID" INTEGER NOT NULL,
    "rewardName" TEXT NOT NULL,
    "costPoint" DOUBLE PRECISION NOT NULL,
    "region" TEXT NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RewardItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RewardSuggest" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "rewardName" TEXT NOT NULL,
    "website" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RewardSuggest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RewardOrder" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "status" "RewardOrderStatus" NOT NULL DEFAULT E'pending',
    "deliveredItem" TEXT,
    "itemID" INTEGER NOT NULL,
    "customFieldValue" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RewardOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OfferHistory" (
    "id" SERIAL NOT NULL,
    "provider" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "action" "OfferAction" NOT NULL,
    "points" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "OfferHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReferralHistory" (
    "id" SERIAL NOT NULL,
    "referrerUsername" TEXT NOT NULL,
    "referredUsername" TEXT NOT NULL,
    "commissionPoints" DOUBLE PRECISION NOT NULL,
    "referenceId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ReferralHistory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- AddForeignKey
ALTER TABLE "LoginLog" ADD CONSTRAINT "LoginLog_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PromotionHistory" ADD CONSTRAINT "PromotionHistory_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PromoCodeHistory" ADD CONSTRAINT "PromoCodeHistory_code_fkey" FOREIGN KEY ("code") REFERENCES "PromoCode"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PromoCodeHistory" ADD CONSTRAINT "PromoCodeHistory_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PtcCampaign" ADD CONSTRAINT "PtcCampaign_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PtcHistory" ADD CONSTRAINT "PtcHistory_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PtcHistory" ADD CONSTRAINT "PtcHistory_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "PtcCampaign"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RewardItem" ADD CONSTRAINT "RewardItem_catalogID_fkey" FOREIGN KEY ("catalogID") REFERENCES "RewardCatalog"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RewardSuggest" ADD CONSTRAINT "RewardSuggest_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RewardOrder" ADD CONSTRAINT "RewardOrder_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RewardOrder" ADD CONSTRAINT "RewardOrder_itemID_fkey" FOREIGN KEY ("itemID") REFERENCES "RewardItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OfferHistory" ADD CONSTRAINT "OfferHistory_username_fkey" FOREIGN KEY ("username") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReferralHistory" ADD CONSTRAINT "ReferralHistory_referrerUsername_fkey" FOREIGN KEY ("referrerUsername") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReferralHistory" ADD CONSTRAINT "ReferralHistory_referredUsername_fkey" FOREIGN KEY ("referredUsername") REFERENCES "User"("username") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReferralHistory" ADD CONSTRAINT "ReferralHistory_referenceId_fkey" FOREIGN KEY ("referenceId") REFERENCES "OfferHistory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
