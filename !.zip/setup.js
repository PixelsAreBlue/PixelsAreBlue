'use strict'

import prompts from 'prompts'
import chalk from 'chalk'
import { execSync } from 'child_process'
import { dirname } from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs-extra'

const currentDir = fileURLToPath(dirname(import.meta.url))

class utils {
    static clear () {
        console.clear()
    }
    static async exec (commandString, workingDir) {
        try {
            const result = await execSync(commandString, {
                cwd: workingDir ? workingDir : currentDir
            })
            return result
        } catch (err) {
            this.raiseError(err.stdout.toString())
        }

    }
    static async raiseError (e){
        console.log(chalk.red('Script crashed with an error'))
        console.error(e)
        process.exit()
    }
    static async resolveDir (startDir, conditions, discard) {
        discard = discard ? discard : ['node_modules']
        let files = []
        const resolver = async function (path) {
            path = path ? path : ''
            return await fs.readdirSync(`${startDir}/${path}`, { withFileTypes: true }).forEach( async file => {
                if(file.isDirectory()) return await resolver(`${path}/${file.name}`)
                if(discard.some(d => file.name.includes(d))) return
                if(conditions){
                    conditions(file)
                    .then(function () {
                        files.push(`${startDir}/${path}/${file.name}`)
                    }).catch(function () {})
                } else { 
                    files.push(`${startDir}/${path}/${file.name}`)
                }
            })
        }
        await resolver()
        return files
    }
    static wait (ms) {
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                resolve()
            }, ms)
        });
    }
}
class compiler {
    async build () {
        //Copy config.json if it missing
        if(!fs.pathExistsSync(currentDir+'/src/config.json')) {
            fs.copyFileSync(currentDir+'/src/config.example.json', currentDir+'/src/config.json')
        }
        console.log (chalk.green('Compiling source code...'))
        await fs.removeSync(currentDir + '/build', { recursive: true })
        const result = await utils.exec('npx tsc --build')
        if(result.toString().trim().length) return raiseError(result.toString())
        console.log (chalk.green('Fixing Imports'))
        await this.fixImports()
        console.log (chalk.green('Filling Missing Files'))
        await this.copyMissingFile ()
        return await utils.wait(5000)
    }
    async copyMissingFile () {
        const compiled = await utils.resolveDir(currentDir+'/build')
        const src = await utils.resolveDir(currentDir+'/src', function (file) {
            return new Promise((resolve, reject) => {
                if(file.name.endsWith('.ts')) return reject()
                resolve()
            })
        })
        src.forEach( async file => {
            const target = file.replace('src', 'build')
            if(!compiled.includes(target)){
                await fs.copySync(file, target)
            }
        })

    }
    async fixImports () {
        const files = await utils.resolveDir(currentDir+'/build', function (file) {
            return new Promise((resolve, reject) => {
                if(!file.name.endsWith('.js')) return reject()
                resolve()
            })
        })
        return await files.forEach( async file => {
            const data = await fs.readFileSync(file, 'utf8')
            if (!data.match(/import .* from/g) && !data.match(/import\(.*\)/g)) return
            const newData = data.replace(/(import .* from\s+['"])(\..*.(?<!.*json))(?=['"])/g, '$1$2.js') // Add .js prefix to import 'something' from 'something' (Exclude: starts with .)
                .replace(/(import\(['"])(\..*.(?<!.*json))(?=['"]\))/g, '$1$2.js')
                .replace(/(import .* from\s+['"])((?!.*(\.|@)).*.\/.*.(?<!.*json))(?=['"])/g, '$1$2.js') // Add .js prefix to import 'something' from 'something/sub' (Exclude: starts with @ or .)
            return await fs.writeFileSync(file, newData)
        })
    }
}

async function main () {
    utils.clear()

    const options = await prompts ({
        type: 'multiselect',
        name: 'value',
        message: 'Pick a feature',
        choices: [
        { title: 'Compile Source Code', value: 'compile', selected: true},
        ],
        hint: '- Space to select. Return to submit'
    })

    utils.clear()

    const confirmation = await prompts({
        type: 'toggle',
        name: 'value',
        message: chalk.red('If you run a setup, the existing compiled files will be removed. \n Are you sure to continue?'),
        initial: false,
        active: 'yes',
        inactive: 'no'
    })

    if(!confirmation.value){
        process.exit()
    }
    

    utils.clear()
    if (options.value[0]) {
        const c = new compiler()
        await c.build()
    }

    utils.clear()
    console.log("Setup done. Press any key to exit")
    process.stdin.setRawMode(true)
    process.stdin.resume()
    process.stdin.on('data', process.exit.bind(process, 0))
}
try {
    main()
} catch (err) {
    utils.raiseError(err)
}