import Mongo from 'mongodb'
import pg from 'pg'

const { MongoClient } = Mongo
const { Client } = pg

const mongoStr = "mongodb://DESKTOP-F18O0TU:27017,DESKTOP-F18O0TU:27018,DESKTOP-F18O0TU:27019/dropgc?replicaSet=rs" //Your MongoDB Connection String
const mongoDB = "dropgc" //Your mongoDB Database
const postgresStr = "postgresql://dropgc:9KHLQJNKpBjjQR6v@localhost:5432/dropgcdev?schema=public" //Your Postgres Connection String

async function main () {

    const start = performance.now()

    console.log('[!] Connecting to the MongoDB Database')

    const mongoClient = await ( async function () {
        return new Promise(function(resolve, reject) {
            MongoClient.connect(mongoStr,{ useNewUrlParser: true },  (err, db) => {
                if (err) {
                    console.error(err)
                } else {
                    console.log("[-] Connected to the MongoDB Database")
                    resolve(db)
                }
            })
        })
    })()

    console.log('[!] Connecting to the PostgreSQL Database')
    const client = new Client({
        connectionString: postgresStr
    })
    await client.connect()
    console.log("[-] Connected to the PostgreSQL Database")

    console.log('-----------------------------------------------------------------------')
    console.log('Running Migration: users > User, LoginLogs]')
    console.log('[!] MongoDB: Fetching User Records....')
    const users = await mongoClient.db(mongoDB).collection('users').find({}).toArray()
    console.log(`[-] ${users.length} records imported`)

    console.log('[!] PostgreSQL: Insert Users...')

    let userCounter = 0

    for (const user of users) {
        await client.query(`
        INSERT INTO "User"(email, username, password, balance, referrer, "authCode", "isAdmin", "isBanned", "isEmailVerified", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)

        `, [user.email,
            user.username,
            user.password,
            user.balance,
            user.referrer,
            user.authCode,
            false,
            user.statuses.isBanned,
            user.statuses.isEmailVerified,
            new Date(user.createdAt).toUTCString(),
            new Date(user.updatedAt).toUTCString()
        ])

        userCounter = userCounter + 1
    }
    console.log(`[-] PostgreSQL: ${userCounter} records inserted`)

    console.log('[!] PostgreSQL: Insert Login Logs...')


    let loginLogCounter = 0

    for (const user of users) {
        for (const loginLog of user.loginLogs) {
            await client.query(`
            INSERT INTO "LoginLog" (username, os, browser, device, ip, timestamp)
            VALUES ($1, $2, $3, $4, $5, $6)
            `, [
                user.username,
                loginLog.os, 
                loginLog.browser,
                loginLog.device,
                loginLog.ip,
                new Date(loginLog.timestamp).toUTCString()
            ])

            loginLogCounter = loginLogCounter + 1
        }
    }

    console.log(`[-] PostgreSQL: ${loginLogCounter} records inserted`)


    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: promotionslogs > PromotionHistory')
    console.log('[!] MongoDB: Fetching Promotions Records....')

    const promotions = await mongoClient.db(mongoDB).collection('promotionslogs').find({}).toArray()
    console.log(`[-] ${promotions.length} records imported`)

    let promotionsCounter = 0

    for (const promotion of promotions) {
        await client.query(`
        INSERT INTO "PromotionHistory"("promotionName", username, points, "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5)
        `, [
            promotion.promotionName,
            promotion.username,
            promotion.points,
            new Date(promotion.createdAt).toUTCString(),
            new Date(promotion.updatedAt).toUTCString()
        ])

        promotionsCounter = promotionsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${promotionsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: promocodes > PromoCode')
    console.log('[!] MongoDB: Fetching promocodes Records....')

    const promoCodes = await mongoClient.db(mongoDB).collection('promocodes').find({}).toArray()
    console.log(`[-] ${promoCodes.length} records imported`)

    let promoCodesCounter = 0

    for (const promoCode of promoCodes) {
        await client.query(`
        INSERT INTO "PromoCode"("code", "points", "maxUse", "expiryDate", "isExpired", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        `,
        [
            promoCode.code,
            promoCode.points,
            promoCode.limit.maxUse,
            promoCode.limit.expiryDate,
            promoCode.status === "expired" ? true : false,
            new Date(promoCode.createdAt).toUTCString(),
            new Date(promoCode.updatedAt).toUTCString()
        ])

        promoCodesCounter = promoCodesCounter + 1
    }
    console.log(`[-] PostgreSQL: ${promoCodesCounter} records inserted`)


    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: promocodelogs > PromoCodeHistory')
    console.log('[!] MongoDB: Fetching promocodelogs Records....')

    const promoCodeLogs = await mongoClient.db(mongoDB).collection('promocodelogs').find({}).toArray()
    console.log(`[-] ${promoCodeLogs.length} records imported`)

    let promoCodeLogsCounter = 0

    for (const log of promoCodeLogs) {
        await client.query(`
        INSERT INTO "PromoCodeHistory"("code", "username", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4)
        `,
        [
            log.code,
            log.username,
            new Date(log.createdAt).toUTCString(),
            new Date(log.updatedAt).toUTCString()
        ])

        promoCodeLogsCounter = promoCodeLogsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${promoCodeLogsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: adcampaigns > PtcCampaign')
    console.log('[!] MongoDB: Fetching adcampaigns Records....')

    const adcampaigns = await mongoClient.db(mongoDB).collection('adcampaigns').find({}).toArray()
    console.log(`[-] ${adcampaigns.length} records imported`)

    let adCampaignCounter = 0

    for (const campaign of adcampaigns) {
        await client.query(`
        INSERT INTO "PtcCampaign"("username", "status", "title", "timer", "maxClicks", "totalCostUsd", "rewardPoint", "url", "paymentMethod", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        `,
        [
            campaign.username,
            campaign.status,
            campaign.title,
            `s${campaign.timer}`,
            campaign.maxClicks,
            campaign.totalCostUsd,
            campaign.rewardPoint,
            campaign.url,
            campaign.paymentMethod,
            new Date(campaign.createdAt).toUTCString(),
            new Date(campaign.updatedAt).toUTCString()
        ])

        adCampaignCounter = adCampaignCounter + 1
    }
    console.log(`[-] PostgreSQL: ${adCampaignCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: adclicklogs > PtcHistory')
    console.log('[!] MongoDB: Fetching adclicklogs Records....')

    const adClickLogs = await mongoClient.db(mongoDB).collection('adclicklogs').find({}).toArray()
    console.log(`[-] ${adClickLogs.length} records imported`)

    let adClickLogsCounter = 0

    for (const log of adClickLogs) {
        await client.query(`
        INSERT INTO "PtcHistory"("username", "campaignId", "isVerified", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5)
        `,
        [
            log.username,
            log.campaignId,
            log.status === "clicked" ? true : false,
            new Date(log.createdAt).toUTCString(),
            new Date(log.updatedAt).toUTCString()
        ])

        adClickLogsCounter = adClickLogsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${adClickLogsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: rewardcatalogs > [RewardCatalog, RewardItem]')
    console.log('[!] MongoDB: Fetching rewardcatalogs Records....')

    const rewardCatalogs = await mongoClient.db(mongoDB).collection('rewardcatalogs').find({}).toArray()
    console.log(`[-] ${rewardCatalogs.length} records imported`)

    let rewardCatalogCounter = 0
    let rewardItemCounter = 0

    console.log('[!] PostgreSQL: Insert RewardCatalog...')
    console.log('[!] PostgreSQL: Insert RewardItem...')

    for (const catalog of rewardCatalogs) {
        const query = await client.query(`
        INSERT INTO "RewardCatalog"("title", "description", "bannerImgUrl", "customField", "customFieldDescription", "isDeleted", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7 ,$8)
        RETURNING id
        `,
        [
            catalog.title,
            catalog.description,
            catalog.bannerImgUrl,
            catalog.customFields.length ? catalog.customFields[0].displayName : null,
            catalog.customFields.length ? catalog.customFields[0].description : null,
            false,
            new Date(catalog.createdAt).toUTCString(),
            new Date(catalog.updatedAt).toUTCString()
        ])
        for (const item of catalog.subItems) {
            await client.query(`
            INSERT INTO "RewardItem"("catalogID", "rewardName", "costPoint", "region", "isDeleted", "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            `,
            [
                query.rows[0].id,
                item.displayName,
                item.costPoint,
                item.region,
                false,
                new Date().toUTCString(),
                new Date().toUTCString()
            ])
    
            rewardItemCounter = rewardItemCounter + 1
        }

        rewardCatalogCounter = rewardCatalogCounter + 1
    }
    console.log(`[-] PostgreSQL: ${rewardCatalogCounter} records inserted`)
    console.log(`[-] PostgreSQL: ${rewardItemCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: rewardsuggestions > RewardSuggest')
    console.log('[!] MongoDB: Fetching rewardsuggestions Records....')

    const rewardSuggestions = await mongoClient.db(mongoDB).collection('rewardsuggestions').find({}).toArray()
    console.log(`[-] ${rewardSuggestions.length} records imported`)

    let rewardSuggestionsCounter = 0

    for (const suggest of rewardSuggestions) {
        await client.query(`
        INSERT INTO "RewardSuggest"("username", "rewardName", "website", "region", "description", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        `,
        [
            suggest.username,
            suggest.name,
            suggest.website,
            suggest.region,
            suggest.description,
            new Date(suggest.createdAt).toUTCString(),
            new Date(suggest.updatedAt).toUTCString()
        ])

        rewardSuggestionsCounter = rewardSuggestionsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${rewardSuggestionsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    const rewardOrders = await mongoClient.db(mongoDB).collection('rewardorders').find({}).toArray()
    console.log(`[!] WARNING: Reward Orders Table has skipped but ${rewardOrders.length} records found`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: offerlogs > OfferHistory')
    console.log('[!] MongoDB: Fetching offerlogs Records....')

    const offerlogs = await mongoClient.db(mongoDB).collection('offerlogs').find({}).toArray()
    console.log(`[-] ${offerlogs.length} records imported`)

    let offerLogsCounter = 0

    for (const log of offerlogs) {
        await client.query(`
        INSERT INTO "OfferHistory"("provider", "username", "transactionId", "action", "points", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        `,
        [
            log.providerName,
            log.username,
            log.transactionId,
            log.pointsAction === "add" ? 'credit' : 'reversal',
            log.points,
            new Date(log.createdAt).toUTCString(),
            new Date(log.updatedAt).toUTCString()
        ])

        offerLogsCounter = offerLogsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${offerLogsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')

    console.log('Running Migration: referralcommissionlogs > ReferralHistory')
    console.log('[!] MongoDB: Fetching referralcommissionlogs Records....')

    const referralcommissionlogs = await mongoClient.db(mongoDB).collection('referralcommissionlogs').find({}).toArray()
    console.log(`[-] ${referralcommissionlogs.length} records imported`)

    let referralcommissionlogsCounter = 0

    for (const log of referralcommissionlogs) {

        const result = await client.query(`
        SELECT * FROM "OfferHistory" WHERE "provider"='${log.providerName}' AND "transactionId"='${log.transactionId}'
        `)

        await client.query(`
        INSERT INTO "ReferralHistory"("referrerUsername", "referredUsername", "commissionPoints", "referenceId", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6)
        `,
        [
            log.commissionToUsername,
            log.earnFromUsername,
            log.commissionPoints,
            result.rows[0].id,
            new Date(log.createdAt).toUTCString(),
            new Date(log.updatedAt).toUTCString()
        ])

        referralcommissionlogsCounter = referralcommissionlogsCounter + 1
    }
    console.log(`[-] PostgreSQL: ${referralcommissionlogsCounter} records inserted`)

    console.log('-----------------------------------------------------------------------')
    
    console.log('The migration have been successful!')
    console.log(`\n Records Migrated:` + (userCounter + loginLogCounter + promotionsCounter + promoCodesCounter + promoCodeLogsCounter + adCampaignCounter + adClickLogsCounter + rewardCatalogCounter + rewardItemCounter + rewardSuggestionsCounter + offerLogsCounter + referralcommissionlogsCounter).toString())
    console.log('Time Elapsed:' + (performance.now() - start).toString())
}

main()