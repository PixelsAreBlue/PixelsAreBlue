import webhookPoster from "./webhookPoster"

export function batchLoader () {
    if (process.env.NODE_APP_INSTANCE && parseInt(process.env.NODE_APP_INSTANCE) !== 0) { //for pm2 cluster mode
        return //is not main instance
    }

    webhookPoster()

}