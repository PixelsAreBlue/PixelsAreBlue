import cron from 'node-cron'
import fetch from 'node-fetch'

export default function webhookPoster (){

    return cron.schedule("*/1 * * * * *", async function() {
        const queue = await global.prisma.webhookQueue.findFirst({
            where: {
                isSent: false,
                isError: false
            },
            orderBy: {
                timestamp: 'asc'
            }
        })

        const currentDate = new Date()

        if (!queue) {
            return
        }
        if (queue.rateLimitUntil && currentDate.getTime() < queue.rateLimitUntil.getTime() ) {
            return
        }


        const post = async function(): Promise<any> {
            const response = await fetch(queue.webhookUrl, {
                method: "POST",
                headers: {
                    "Accept": 'application/json',
                    "Content-type": 'application/json'
                },
                body: JSON.stringify({
                    "embeds": [
                        {
                            "timestamp": queue.timestamp,
                            "color": queue.bgColor,
                            "fields": queue.fields,
                        }
                    ]
                })
            })

            if(response.ok) { 
                await global.prisma.webhookQueue.update({
                    where: {
                        id: queue.id
                    },
                    data: {
                        isSent: true
                    }
                })
                return null
            } else {
                const json: any = await response.json()

                if (json.retry_after && parseInt(json.retry_after)) {
                    
                    await global.prisma.webhookQueue.update({
                        where: {
                            id: queue.id
                        },
                        data: {
                            rateLimitUntil: new Date(currentDate.setMilliseconds(currentDate.getMilliseconds() + json.retry_after))
                        }
                    })

                } else {
                    console.error(`Webhook Error ${JSON.stringify(json)}`)
                    await global.prisma.webhookQueue.update({
                        where: {
                            id: queue.id
                        },
                        data: {
                            isError: true
                        }
                    })
                }
            }
        }

        try {
            post()
        } catch (error:any) {
            console.error(error)
        }
    })
}