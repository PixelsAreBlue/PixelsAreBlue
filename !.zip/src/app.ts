import path from 'path'
import cookieParser from 'cookie-parser'
import express from 'express'
import session from 'express-session'
import { isPortTaken } from './utils/Utils'
import localeSwitcher from './middleware/localeSwitcher'

import { default as config } from './config.json'

import { fileURLToPath } from 'url'

import router from './routers/router'

import dotenv from 'dotenv'
dotenv.config({ path: '../.env' })

import pgStore from 'connect-pg-simple'

import Logger from './services/Logger'

const PgSession = pgStore(session)

import Pg from 'pg'

const pgPool = new Pg.Pool({ connectionString: process.env.DATABASE_URL })


import prisma from '@prisma/client'
import httpLoggerMiddleware from './middleware/httpLogger'

import { batchLoader } from './batches/index'

const { PrismaClient } = prisma

const currentDir = fileURLToPath(path.dirname(import.meta.url))

const app: express.Express = express()


app.set('views', path.join(currentDir, 'views'))
  .set('view engine', 'pug')
  .set('trust proxy', '127.0.0.1')

app.disable('x-powered-by')

app.use(express.json())
  .use(express.urlencoded({ extended: true }))
  .use(cookieParser())
  .use(express.static(path.join(currentDir, 'public')))
  .use(session(
    { 
      secret: 'secret', 
      resave: false,
      cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 }, // 30 days
      saveUninitialized: true,
      store: new PgSession ({
        pool: pgPool
      })
  }))

const prismaClient = new PrismaClient()
global.prisma = prismaClient

//set up Prisma Client
app.use(async function (req: express.Request, res:express.Response, next:express.NextFunction) {
  req.prisma = prismaClient
  next()
})
//set sentry dsn variable
app.use( async function (req: express.Request, res:express.Response, next:express.NextFunction) {
  res.locals.sentryDSN = config.apikeys.sentryDSN
  next()
})

app.use(httpLoggerMiddleware)
app.use(localeSwitcher)

async function server () {

  router(app)

  //connect to the postgresql database
  await prismaClient.$connect().then ( () => {
    console.log("Connected to the PostgreSQL database.")
  }).catch((err) => {
    console.log("Unable to connect to the PostgreSQL database.")
    console.error(err)
  })

  batchLoader()

// catch 404 and forward to error handler
app.use(function (req: express.Request, res: express.Response, next:Function) {
  res.status(404);
  res.render('errorPages/404')
})

  let port = 3000
  const getPort:any = async function (){
    if(await isPortTaken(port)){
      port++
      return await getPort()
    }
  }
  await getPort()

  app.listen(port, function(){
    console.log(`Web Server is running on port ${port}`)
  })
  const logger = new Logger('System')
  await logger.logEvent({
    logLevel: 'debug',
    eventName: 'Server Started',
    description: `Web server is running on port ${port}`,
    actionInfo: 'Server Started',
    actionType: 'create',
    user: null,
    ip: null
  })
}
server().catch((e) => {
  throw e
})