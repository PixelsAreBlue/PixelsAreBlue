class rewardCatalog {
    static addSubItem(name = null, costPoint = null, region = null){
        const fieldNumber = $('#subItemsContainer').find('.flex-row').length + 1
        console.log(fieldNumber)
        $('#subItemsContainer').append(`
            <div class="d-flex flex-row">
                <div class="form-group">
                    <input class="form-control" type="text" name="subItems[][${fieldNumber}][displayName]" value="${name || ''}" placeholder="Display Name" required /> 
                </div>
                <div class="form-group">
                    <input class="form-control" type="number" name="subItems[][${fieldNumber}][costPoint]" value="${costPoint || ''}" placeholder="Cost Point" required />
                </div>
                <div class="form-group">
                    <input class="form-control" type="text" name="subItems[][${fieldNumber}][region]" value="${region || ''}" placeholder="region" required />
                </div>
            </div>
        `)
    }
}
$(document).ready(function(){
    $(document).on('click', '.deleteSubItemButton', function (el) {
        $(el.currentTarget).parent().parent().remove()
    })
})