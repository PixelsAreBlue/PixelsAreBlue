import express from 'express'
import config from '../config.json'

import * as signupController from '../controllers/auth/signupController'
import * as loginController from '../controllers/auth/loginController'
import * as resetPasswordController from '../controllers/auth/resetPasswordController'
import * as logoutController from '../controllers/auth/logoutController'
import * as verifyController from '../controllers/auth/verifyController'

const router: express.Router = express.Router()
    
router
    .use(async function (req: express.Request, res:express.Response, next:express.NextFunction) {
        // Set default view parameters
        res.locals.session = req.session
        res.locals.data = {
            req: req,
            session: req.session,
            config: config,
            userData: req.session.loginUser && req.session.loginUser.length ? await req.prisma.user.findFirst({
                where: {
                    username: req.session.loginUser
                }
            }) : null
        }
        next()
    })

async function checkLoginMiddleware(req: express.Request, res: express.Response, next:Function) {
    if(!req.session.loginUser) return res.redirect('/login')
        
    next()
}
    
router
    .get('/signup', signupController.doGetSignup)
    .get('/login', loginController.doGetLogin)
    .get('/verify', checkLoginMiddleware, verifyController.doGetVerify)
    .get('/reset-password', resetPasswordController.doGetReset)
    .get('/logout', logoutController.doGetLogout)

router.post('/signup', signupController.doPostAjax)
    .post('/login', loginController.doPostLogin)
    .post('/verify', checkLoginMiddleware, verifyController.doPostVerify)
    .post('/reset-password', resetPasswordController.doPostReset)
export default router