import express from 'express'
import config from '../config.json'
import csrf from 'csurf'
import { setOfferwalls as setOfferwallsMiddleware } from '../middleware/offerwallConf'

import * as dashboardController from '../controllers/dashboard/dashboardController'
import * as settingsController from '../controllers/dashboard/settingsController'
import * as offerController from '../controllers/dashboard/offerController'
import * as offerwallController from '../controllers/dashboard/offerwallController'
import * as promotionsController from '../controllers/dashboard/promotionsController'
import * as redeemController from '../controllers/dashboard/redeemController'

const router: express.Router = express.Router()
const csrfProtection = csrf({ cookie: false })
    
router
    .use(async function (req: express.Request, res:express.Response, next:express.NextFunction) {
        // Set default view parameters

        res.locals.session = req.session
        res.locals.data = {
            req: req,
            userData: req.session.loginUser && req.session.loginUser.length ? await req.prisma.user.findFirst({
                where: {
                    username: req.session.loginUser
                }
            }) : null,
            session: req.session,
            config: config
        }
        next()
    })
    .use(async function  (req: express.Request, res: express.Response, next:Function) {
        // Check if logged in
        if (!req.session.loginUser || !req.session.loginUser.length) { //* Prevent where query from being undefined
            return res.redirect('/login')
        }
        const user = await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        })

        if(!user) return res.redirect('/login')
        if(user!.isBanned) return res.render('dashboard/bannedView')
        if(!user!.isEmailVerified) return res.redirect('/verify')
        
        next()
    })


router.get('/', dashboardController.doGetDashboard)
    .get('/invite', dashboardController.doGetInvite)
    .get('/settings', settingsController.doGetSettings)
    .get('/activity', dashboardController.doGetActivity)
    .get('/activity/fetch', dashboardController.doGetFetchActivity)
    .get('/offers', offerController.doGetOffers)
    .get('/offers/fetch', offerController.doGetFetch)
    .get('/offerwall', setOfferwallsMiddleware, offerwallController.doGetOfferwalls)
    .get('/offerwall/:offerwallId', setOfferwallsMiddleware, offerwallController.doGetOfferwall)
    .get('/videowall', setOfferwallsMiddleware, offerwallController.doGetVideoWalls)
    .get('/promotions', promotionsController.doGetPromotions)
    .get('/promotions/claim/discord', promotionsController.doGetDiscord)
    .get('/redeem', redeemController.doGetCatalog)
    .get('/redeem/suggest', redeemController.doGetSuggest)
    .get('/redeem/:catalogID', csrfProtection, redeemController.doGetRedeem)
router.post('/', dashboardController.doPostDashboard)
    .post('/settings', settingsController.doPostSettings)
    .post('/redeem/suggest', redeemController.doPostSuggest)
    .post('/redeem/:catalogID', csrfProtection, redeemController.doPostRedeem)
    .post('/promotions', promotionsController.doPostPromotions)

export default router