import express from 'express'

import homeRouter from './homeRouter'
import dashboardRouter from './dashboardRouter'
import adminRouter from './adminRouter'
import apiRouter from './apiRouter'
import authRouter from './authRouter'

export default function (app:express.Express) {
    app.use('/', homeRouter)
        .use('/', authRouter)
        .use('/dashboard', dashboardRouter)
        .use('/admin', adminRouter)
        .use('/api', apiRouter)
}