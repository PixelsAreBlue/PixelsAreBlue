import express from 'express'
import config from '../config.json'
import * as homeController from '../controllers/home/homeController'

const router: express.Router = express.Router()
    
router
    .use(async function (req: express.Request, res:express.Response, next:express.NextFunction) {
        // Set default view parameters
        res.locals.session = req.session
        res.locals.data = {
            req: req,
            session: req.session,
            config: config
        }
        next()
    })
    .use( async function (req: express.Request, res:express.Response, next:express.NextFunction) {
        // Check referral
        if(req.session.loginUser) return next()
        if(req.query.ref && req.query.ref.length && await req.prisma.user.count({
            where: {
                username: req.query.ref as string
            }
        }) > 0){
            req.session.referral = req.query.ref
        }
        next()
    })
    
router
    .get('/', homeController.doGetHome)
    .get('/terms', homeController.doGetToS)
    .get('/about', homeController.doGetAbout)

export default router