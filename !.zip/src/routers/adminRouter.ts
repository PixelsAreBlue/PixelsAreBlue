import express from 'express'
import config from '../config.json'

import * as adminController from '../controllers/admin/adminController'
import * as userController from '../controllers/admin/userController'
import * as rewardController from '../controllers/admin/rewardController'
import * as offerController from '../controllers/admin/offerController'
import * as promoCodeController from '../controllers/admin/promoCodeController'
import * as auditLogController from '../controllers/admin/auditLogController'
import * as promotionController from '../controllers/admin/promotionController'
import * as webhookController from '../controllers/admin/webhookController'
import csrf from 'csurf'
import setCsrfTokenMiddleware from '../middleware/setCsrfToken'


const router: express.Router = express.Router()
const csrfProtection = csrf({ cookie: false })

router
    .use(async function (req: express.Request, res:express.Response, next:express.NextFunction) {
        // Set default view parameters

        res.locals.session = req.session
        res.locals.data = {
            req: req,
            userData: req.session.loginUser && req.session.loginUser.length ? await req.prisma.user.findFirst({
                where: {
                    username: req.session.loginUser
                }
            }) : null,
            session: req.session,
            config: config
        }
        next()
    })
    .use(async function (req: express.Request, res: express.Response, next:Function) {
        //check if logged in
        if(!req.session.loginUser || !req.session.loginUser.length) return res.redirect('/login')
        next()
    })
    .use (async function (req: express.Request, res: express.Response, next:Function) {
        //check if admin

        const user = await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        })
        if(!user!.isAdmin) return res.send('You are not admin')
        next()
    })

router
    .get('/', csrfProtection, setCsrfTokenMiddleware, adminController.doGetOverView)
    .get('/user-management', userController.doGetUsers)
    .get('/user-management/:username', csrfProtection, setCsrfTokenMiddleware, userController.doGetUser)
    .get('/login-logs', userController.doGetLoginLogs)
    .get('/reward/catalog', rewardController.doGetCatalog)
    .get('/reward/catalog/add', csrfProtection, setCsrfTokenMiddleware, rewardController.doGetCatalogAdd)
    .get('/reward/catalog/edit/:catalogID', csrfProtection, setCsrfTokenMiddleware, rewardController.doGetCatalogEdit)
    .get('/reward/catalog/edit/:catalogID/delete/:itemID', rewardController.doGetDeleteSubItem)
    .get('/reward/catalog/delete/:catalogID', rewardController.doGetCatalogDelete)
    .get('/reward/order/:orderID', csrfProtection, setCsrfTokenMiddleware, rewardController.doGetOrder)
    .get('/reward/orders', rewardController.doGetOrders)
    .get('/reward/suggestions', rewardController.doGetSuggestions)
    .get('/offer/logs', offerController.doGetLogs)
    .get('/offer/referral', offerController.doGetReferralHistory)
    .get('/promo-code', promoCodeController.doGetManage)
    .get('/promo-code/history', promoCodeController.doGetHistory)
    .get('/promo-code/new', csrfProtection, setCsrfTokenMiddleware, promoCodeController.doGetCreate)
    .get('/promo-code/deactivate/:code', promoCodeController.doGetDeactivate)
    .get('/audit-log', auditLogController.doGetAuditLogs)
    .get('/promotion', promotionController.doGetPromotion)
    .get('/webhook', csrfProtection, setCsrfTokenMiddleware, webhookController.doGetWebhook)
    .get('/jackpot-history', adminController.doGetJackpotHistory)

router 
    .post('/', csrfProtection, setCsrfTokenMiddleware, adminController.doPostOverview)
    .post('/user-management/:username', csrfProtection, setCsrfTokenMiddleware, userController.doPostUser)
    .post('/reward/catalog/add', csrfProtection, setCsrfTokenMiddleware, rewardController.doPostCatalogAdd)
    .post('/reward/catalog/edit/:catalogID', csrfProtection, setCsrfTokenMiddleware, rewardController.doPostCatalogEdit)
    .post('/reward/order/:orderID', csrfProtection, setCsrfTokenMiddleware, rewardController.doPostOrder)
    .post('/promo-code/new', csrfProtection, setCsrfTokenMiddleware, promoCodeController.doPostCreate)
    .post('/webhook', csrfProtection, setCsrfTokenMiddleware, webhookController.doPostWebhook)

export default router
