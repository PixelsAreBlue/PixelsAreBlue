import express from 'express'

import WannadsController from '../controllers/api/offerwallApis/WannadsController'
import CpxController from '../controllers/api/offerwallApis/CpxController'
import KiwiwallController from '../controllers/api/offerwallApis/KiwiwallController'
import MediumpathController from '../controllers/api/offerwallApis/MediumpathController'
import BitlabsController from '../controllers/api/offerwallApis/BitlabsController'
import LootablyController from '../controllers/api/offerwallApis/lootablyController'
import OpinionCapitalController from '../controllers/api/offerwallApis/OpinionCapitalController' 

const wannadsController = new WannadsController
const cpxController = new CpxController
const kiwiwallController = new KiwiwallController
const mediumpathController = new MediumpathController
const bitlabsController = new BitlabsController
const lootablyController = new LootablyController
const opinionCapitalController = new OpinionCapitalController

const router: express.Router = express.Router()

router
    .get('/offerwalls/wannads', wannadsController.doGet.bind(wannadsController))
    .get('/offerwalls/cpx', cpxController.doGet.bind(cpxController))
    .get('/offerwalls/kiwiwall', kiwiwallController.doGet.bind(kiwiwallController))
    .get('/offerwalls/bitlabs', bitlabsController.doGet.bind(bitlabsController))
    .get('/offerwalls/lootably', lootablyController.doGet.bind(lootablyController))
    .get('/offerwalls/opinioncapital', opinionCapitalController.doGet.bind(opinionCapitalController))

router
    .post('/offerwalls/mediumpath', mediumpathController.doPost.bind(mediumpathController))

export default router