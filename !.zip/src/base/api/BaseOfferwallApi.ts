import { default as config } from '../../config.json'
import express from 'express'
import fetch from 'node-fetch'

interface Params {
    providerName: string | null
}
export default class BaseOfferwallApi {
    protected providerName: string | null 
    public constructor ({providerName = null }: Params) {
        this.providerName = providerName
    }
    public async addBalance (username:string, points:number, transactionId: string, options = { applyReferral: true }) {

        if (!username || !username.length) throw new Error('No user provided')

        const user = await global.prisma.user.findFirst({
            where: {
                username: username
            }
        })
        /*  
            If user is not exist, throw a error Because this method call is not valid. you have to validate it on the controller 
        */
        if(!user) throw new Error('User not exist')

        points = Math.abs(points) /* points must be absolute value */

        await global.prisma.$transaction(async (prisma) => {
            await prisma.user.update({
                where: {
                    username: username
                },
                data: {
                    balance: {
                        increment: points
                    }
                }
            })
            const o = await prisma.offerHistory.create({
                data: {
                    provider: this.providerName as string,
                    username: username,
                    points: points,
                    transactionId: transactionId,
                    action: 'credit'
                }
            })
            if(options.applyReferral && user.referrer && user.referrer.length) {
                const rate = 10 // %

                const commission = rate * o.points / 100

                await prisma.user.update({
                    where: {
                        username: user.referrer
                    },
                    data: {
                        balance: {
                            increment: commission
                        }
                    }
                })

                await prisma.referralHistory.create({
                    data: {
                        referrerUsername: user.referrer,
                        referredUsername: user.username,
                        commissionPoints: commission,
                        referenceId: o.id
                    }
                })
        
            }
        })
    }
    public async isNewTransaction (transactionId: string) {
        const query = await global.prisma.offerHistory.count({
            where: {
                provider: this.providerName as string,
                transactionId: transactionId
            }
        })
        return query === 0
    }
    public async reduceBalance (username:string, points:number, transactionId: string, options = {}) {
        if (!username || !username.length) throw new Error('No user provided')

        const user = await global.prisma.user.findFirst({
            where: {
                username: username
            }
        })

        /* 
            If user is not exist, throw a error Because this method call is not valid. you have to validate it on the controller
        */
        if(!user) throw new Error('User not exist')
        
        points = Math.abs(points) /* points must be absolute value */

        await global.prisma.$transaction([
            global.prisma.user.update({
                where: {
                    username: username
                },
                data: {
                    balance: {
                        decrement: points
                    }
                }
            }),
            global.prisma.offerHistory.create({
                data: {
                    provider: this.providerName as string,
                    username: username,
                    points: points,
                    transactionId: transactionId,
                    action: 'reversal'
                }
            })
        ])
    }
    //Send error to Webhook
    public async errorLogger (reason: string, req:express.Request) {
        const providerName: any = this.providerName
        if(config.discord.webhooks.offerLog) {
            await req.prisma.webhookQueue.create({
                data: {
                    webhookUrl: config.discord.webhooks.offerLog,
                    timestamp: new Date(),
                    bgColor: 15158332,
                    fields: [
                        {
                            "name": "Provider",
                            "value": providerName
                        },
                        {
                            "name": "Error Reason",
                            "value": reason
                        },
                        {
                            "name": "API Caller IP",
                            "value": req.ip,
                        }
                    ]
                }
            })
        }
    }
    //Send transaction to webhook
    public async infoLogger (transactionId:string, req:express.Request){
        const providerName: any = this.providerName
        const transaction = await req.prisma.offerHistory.findFirst({
            where: {
                provider: providerName,
                transactionId: transactionId
            }
        })
        if(config.discord.webhooks.offerLog) {

            await req.prisma.webhookQueue.create({
                data: {
                    webhookUrl: config.discord.webhooks.offerLog,
                    timestamp: new Date(),
                    bgColor: 3066993,
                    fields: [
                        {
                            "name": "Provider",
                            "value": providerName
                        },
                        {
                            "name": "Username",
                            "value": transaction!.username
                        },
                        {
                            "name": "Transaction ID",
                            "value": transaction!.transactionId
                        },
                        {
                            "name": "Points Action",
                            "value": transaction!.action
                        },
                        {
                            "name": "Points Value",
                            "value": transaction!.points
                        },
                        {
                            "name": "API Caller IP",
                            "value": req.ip,
                        }
                    ]
                }
            })
        }
    }
}