import config from '../config.json'
import fetch from 'node-fetch'

type logLevel = 'debug'|'info'|'warn'|'error'|'fatal'
type actionType = 'create'|'read'|'update'|'delete'

interface log {
    logLevel: logLevel,
    eventName: String,
    description: String | null,
    actionInfo: String,
    actionType: actionType,
    user: String | null,
    ip: String | null
}

export default class Logger {
    protected resourceName
    protected prisma
    public constructor (resourceName: string, prismaClient: any = global.prisma) { //Define own prisma client here when use $transaction
        this.resourceName = resourceName
        this.prisma = prismaClient
    }
    public async logEvent ({
        logLevel,
        eventName,
        description = null,
        actionInfo,
        actionType,
        user = null,
        ip = null
    }: log) {
        const log = await this.prisma.auditLog.create({
            data: {
                logLevel: logLevel,
                resourceName: this.resourceName,
                eventName: eventName,
                description: description,
                actionInfo: actionInfo,
                actionType: actionType,
                user: user,
                ip: ip
            }
        })
        if (config.discord.webhooks.auditLog) {
            let color = 10070709

            if (log.logLevel === "debug") {
                color = 9807270
            } else if (log.logLevel === "info") {
                color = 5793266
            } else if (log.logLebel === "warn") {
                color = 16705372
            } else if (log.logLevel === "error" ) {
                color = 15158332
            } else if (log.logLevel === "fatal") {
                color = 15158332
            }

            await global.prisma.webhookQueue.create({
                data: {
                    webhookUrl: config.discord.webhooks.auditLog,
                    timestamp: log.timestamp,
                    bgColor: color,
                    fields: [
                        {
                            "name": "Log Level",
                            "value": `${log.logLevel}`
                        },
                        {
                            "name": "Resource Name",
                            "value": `${log.resourceName}`
                        },
                        {
                            "name": "Event",
                            "value": `${log.eventName}`
                        },
                        {
                            "name": "Description",
                            "value": `${log.description}`
                        },
                        {
                            "name": "Action Info",
                            "value": `${log.actionInfo}`
                        },
                        {
                            "name": "Action Type",
                            "value": `${log.actionType}`
                        },
                        {
                            "name": "User",
                            "value": `${log.user}`
                        },
                        {
                            "name": "ip",
                            "value": `${log.ip}`
                        }
                    ]
                }
            })
        }
        return log
    }
}