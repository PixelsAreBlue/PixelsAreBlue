import { fileURLToPath } from 'url'
import { dirname } from 'path'
import { createTransport } from 'nodemailer'
import { default as config } from '../config.json'
import { join } from 'path'
import { renderFile } from 'pug'
import Logger from './Logger'

const currentDir = fileURLToPath(dirname(import.meta.url))

const transporter = createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    auth: {
        user: config.smtp.user,
        pass: config.smtp.pass
    }
})

export default class EmailService {
    protected logger
    constructor () {
        this.logger = new Logger('EmailService')
    }
    async sendEmail (to:string, subject:string, template:string, templateParameters:object = {}){
        if(!template.endsWith('.pug')) template = template+".pug"
        const result = await transporter.sendMail({
            from: config.smtp.from,
            to: to,
            subject: subject,
            html: renderFile(join(currentDir+'/../emailTemplates', template), { ...templateParameters, config: config })
        })

        await this.logger.logEvent({
            logLevel: 'info',
            eventName: 'Email Sent',
            description: `A email has been sent to ${to}`,
            actionInfo: 'Email Sent',
            actionType: 'read',
            user: null,
            ip: null
        })

        return result
    }
    emailValid (email: string): Boolean {
        const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        return re.test(email)
    }
}