import express from 'express'
import { formError } from '../../types/types'

export async function doGetVerify (req: express.Request, res: express.Response) {

    const user = await req.prisma.user.findFirst({
        where: {
            username: req.session.loginUser
        }
    })
    if (user!.isEmailVerified) {
        // already verified
        return res.redirect('/dashboard')
    }
    res.render('auth/verifyView')
}
export async function doPostVerify (req: express.Request, res: express.Response) {
    let formErrors: formError[] = []

    const user = await req.prisma.user.findFirst({
        where: {
            username: req.session.loginUser
        }
    })
    if (user!.isEmailVerified) {
        // already verified
        return res.redirect('/dashboard')
    }


    const validate = /^[0-9]*$/.test(req.body.code) //Must only contain numbers
    if (validate && user!.authCode === req.body.code) {
        await req.prisma.user.update({
            where: {
                username: req.session.loginUser,
            },
            data: {
                isEmailVerified: true, // mark as verified
                authCode: null //reset code
            }
        })
        return res.redirect('/dashboard')
    } 
    formErrors.push({ fieldName: 'code', message: 'The code you entered is invalid' })

    res.render('auth/verifyView', { formErrors: formErrors })
}