import express from 'express'
import RecaptchaClient from '../../utils/RecaptchaClient'
import { formError } from '../../types/types'
import EmailService from '../../services/EmailService'
import validateEmail from '../../validators/validateEmail'
import validatePassword from '../../validators/validatePassword'

export async function doGetReset (req: express.Request, res: express.Response) {
    res.render('auth/resetPasswordView')
}
export async function doPostReset (req: express.Request, res: express.Response) {
    const emailService = new EmailService

    if(req.query.confirm === "true"){
        let formErrors: formError[] = []

        //validate input
        const emailInvalid = validateEmail(req.body.email)

        if (emailInvalid) {
            formErrors.push({ fieldName: 'email', message:emailInvalid })
        }

        const passwordInvalid = validatePassword(req.body.password)

        if (passwordInvalid){
            formErrors.push({ fieldName: 'password', message: passwordInvalid })
        }

        if(req.body.password !== req.body.confirmPassword){
            formErrors.push({ fieldName: 'password', message:'password confirmation does not match.' })
            formErrors.push({ fieldName: 'confirmPassword', message:'password confirmation does not match.' })
        }

    
        if(formErrors.length) return res.render('auth/resetPasswordConfirmationView', { formErrors: formErrors, email: req.body.email })
    

        //check
        const user = await req.prisma.user.findFirst({
            where: {
                email: req.body.email
            }
        })

        if (!user) {
            formErrors.push({ fieldName: 'email', message: 'Could not find your account' })
        }

        if(formErrors.length) return res.render('auth/resetPasswordConfirmationView', { formErrors: formErrors, email: req.body.email })


        const validate = /^[0-9]*$/.test(req.body.code) //Must only contain numbers
        if(validate && user!.authCode === req.body.code){

            const result = await req.prisma.user.update({
                where: {
                    username: user!.username
                },
                data: {
                    authCode: null,
                    password: req.body.password
                }
            })

            req.session.loginUser = result!.username

            return res.redirect('/dashboard')
        } 
        formErrors.push({ fieldName: 'code', message: 'The code you entered is invalid' })
        res.render('auth/resetPasswordConfirmationView', { formErrors: formErrors, email: req.body.email })
    } else {
        let formErrors: formError[] = []
        if(!await RecaptchaClient.verifyRecaptchaToken(req.body['g-recaptcha-response'])){
            formErrors.push({ fieldName: 'email', message:'captcha error' })
        }

        // validate input

        const emailInvalid = validateEmail(req.body.email)

        if (emailInvalid) {
            formErrors.push({ fieldName: 'email', message: emailInvalid })
        }

        if(formErrors.length) return res.render('auth/resetPasswordView', { formErrors: formErrors })

        // check

        const user = await req.prisma.user.findFirst({
            where: {
                email: req.body.email
            }
        })

        if (!user) {
            formErrors.push({ fieldName: 'email', message: 'Could not find your account' })
        }

        if(formErrors.length) return res.render('auth/resetPasswordView', { formErrors: formErrors })
    

        //validation ok

        const authCode = Math.floor(Math.random() * (99999999 - 1) + 1).toString()
        
        await req.prisma.user.update({
            where: {
                username: user!.username
            },
            data: {
                authCode: authCode
            }
        })
        await emailService.sendEmail(user!.email, 'Resetting your DropGC password', 'resetPassword', { username: user!.username, code: authCode })

        res.render('auth/resetPasswordConfirmationView', { email: req.body.email })
    }
}