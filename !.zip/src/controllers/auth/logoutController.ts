
import express from 'express'

export async function doGetLogout (req: express.Request, res: express.Response) {
    req.session.destroy( function () {
        res.redirect('/')
    })
}