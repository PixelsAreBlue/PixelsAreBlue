import express from 'express'
import { formError } from '../../types/types'
import DeviceDetector from 'node-device-detector'
import DeviceHelper from 'node-device-detector/helper'
import validateUsername from '../../validators/validateUsername'
import validateEmail from '../../validators/validateEmail'
import validatePassword from '../../validators/validatePassword'

const detector = new DeviceDetector

export function doGetLogin (req: express.Request, res: express.Response) {
    res.render('auth/loginView')
}
export async function doPostLogin  (req: express.Request, res: express.Response) {

    let formErrors: formError[] = []


    // validate input
    const usernameInvalid = validateUsername(req.body.usernameoremail)
    const emailInvalid = validateEmail(req.body.usernameoremail)


    if (usernameInvalid && emailInvalid) {
        formErrors.push({ fieldName: 'usernameoremail', message: 'Username or Email is invalid' })
    }

    const passwordInvalid = validatePassword(req.body.password)

    if (passwordInvalid) {
        formErrors.push({ fieldName: 'password', message: passwordInvalid })
    }

    if (formErrors.length) {
        return res.render('auth/loginView', { formErrors: formErrors })
    }

    //find user

    const query = await req.prisma.user.findFirst({
        where: {
            OR: [
                {
                    username: req.body.usernameoremail
                },
                {
                    email: req.body.usernameoremail
                }
            ]
        }
    })

    if (!query) {
        formErrors.push({ fieldName: 'usernameoremail', message: 'Could not find your account' })
    } else if (query.password !== req.body.password) {
        formErrors.push({ fieldName: 'password', message: 'password does not match' })
    }

    if(formErrors.length){
        res.render('auth/loginView', { formErrors: formErrors })
    } else {

        // Create logger

        const result = req.headers['user-agent'] && req.headers['user-agent'].length ? detector.detect(req.headers['user-agent']) : null

        await req.prisma.loginLog.create({
            data: {
                username: query!.username,
                os: result ? result.os.name || 'unknown' : 'unknown',
                browser: result ? `${result.client.name || 'unknown'} ${result.client.version || 'unknown'}` : 'unknown',
                device: result && DeviceHelper.isMobile(result) || DeviceHelper.isTablet(result) ? 'mobile': 'desktop',
                ip: req.ip
            }
        })

        // login successful
        req.session.loginUser = query!.username
        res.redirect('/dashboard')
    }
}