import RecaptchaClient from '../../utils/RecaptchaClient'
import express from 'express'
import { formError } from '../../types/types'
import EmailService from '../../services/EmailService'
import validateEmail from '../../validators/validateEmail'
import validateUsername from '../../validators/validateUsername'
import validatePassword from '../../validators/validatePassword'

export async function doGetSignup (req: express.Request, res: express.Response) {
    res.render('auth/signupView')
}

export async function doPostAjax (req: express.Request, res: express.Response) {
    let formErrors: formError[] = []

    const emailService = new EmailService


    // validate input
    const usernameInvalid = validateUsername(req.body.username)
    if (usernameInvalid) {
        formErrors.push({ fieldName: 'username', message: usernameInvalid })
    }

    const emailInvalid = validateEmail(req.body.email)
    if (emailInvalid) {
        formErrors.push({ fieldName: 'email', message: emailInvalid })
    }

    const passwordInvalid = validatePassword(req.body.password)

    if (passwordInvalid) {
        formErrors.push({ fieldName: 'password', message: passwordInvalid })
    }

    if(req.body.password !== req.body.confirmPassword){
        formErrors.push({ fieldName: 'password', message:'password confirmation does not match.' })
        formErrors.push({ fieldName: 'confirmPassword', message:'password confirmation does not match.' })
    }

    if(formErrors.length) return res.json({ success: false, formErrors: formErrors })


    // Check Availability
    if(await req.prisma.user.count({ 
        where: {
            email: req.body.email
        }
    }) > 0) { 
        formErrors.push({ fieldName: 'email', message: 'Email is already used' })
    }
    
    if (await req.prisma.user.count({
        where: {
            username: req.body.username
        }
    }) > 0){
        formErrors.push({ fieldName: 'username', message: 'Username is already taken' })
    }
    

    if(!await RecaptchaClient.verifyRecaptchaToken(req.body['g-recaptcha-response'])){
        formErrors.push({ fieldName: 'email', message:'captcha error' })
    }

    if(formErrors.length) return res.json({ success: false, formErrors: formErrors })


    //validation ok
    try {
        const authCode = Math.floor(Math.random() * (99999999 - 1) + 1).toString()
        const referral = req.body.referral && req.body.referral.length && await req.prisma.user.count({ where: { username: req.body.referral } }) > 0 ? req.body.referral : null

        await emailService.sendEmail(req.body.email, 'Activate your DropGC account', 'verifyEmail', { username: req.body.username, code: authCode })
    
        const result = await req.prisma.user.create({
            data: {
                username: req.body.username,
                email: req.body.email,
                password: req.body.password,
                referrer: referral,
                authCode: authCode
            }
        })
        req.session.loginUser = result.username
        res.json({ success: true })
    } catch (error) {
        console.error(error)
        formErrors.push({ fieldName: 'email', message:'Something went wrong Please try again later' })
        res.json({ success: false, formErrors:formErrors })
    }

}