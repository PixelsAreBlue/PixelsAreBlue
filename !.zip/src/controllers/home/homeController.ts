import express from 'express'

export const doGetHome = function (req:express.Request, res:express.Response ) {
    res.render('home/homeView')
}
export const doGetToS = function (req:express.Request, res:express.Response ) {
    res.render('home/tosView')
}
export const doGetAbout = function (req: express.Request, res: express.Response ){
    res.render('home/aboutView')
}