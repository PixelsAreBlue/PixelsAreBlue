import express from 'express'
import { formError } from '../../types/types'
import validatePassword from '../../validators/validatePassword'
import validateEmail from '../../validators/validateEmail'
import EmailService from '../../services/EmailService'


export async function doGetSettings (req: express.Request, res: express.Response) {
    res.render('dashboard/settingsView')
}

export async function doPostSettings (req: express.Request, res: express.Response) {
    if (req.body.action === 'changePassword') {
        let formErrors: formError[] = []
        const user = await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        })

        const passwordInvalid = validatePassword(req.body.newPassword)
        if (passwordInvalid) {
            formErrors.push({ fieldName: 'newPassword', message: passwordInvalid })
        }

        if(req.body.newPassword !== req.body.confirmNewPassword){
            formErrors.push({ fieldName: 'newPassword', message:'password confirmation does not match.' })
            formErrors.push({ fieldName: 'confirmNewPassword', message:'password confirmation does not match.' })
        }
        if(req.body.currentPassword !== user!.password) formErrors.push({ fieldName: 'currentPassword', message:'Current password does not match.' })
    
        if(formErrors.length) return res.render('dashboard/settingsView', { formErrors: formErrors })

        await req.prisma.user.update({
            where: {
                username: req.session.loginUser
            },
            data: {
                password: req.body.newPassword
            }
        })
        res.render('dashboard/settingsView', { successMessage: 'Your password has been successfully changed' })
    } else if (req.body.action === 'changeEmail') {
        const emailService = new EmailService
        let formErrors: formError[] = []

        const emailInvalid = validateEmail(req.body.newEmail)

        if (emailInvalid) formErrors.push({
            fieldName:'newEmail',
            message: emailInvalid
        })

        const passwordInvalid = validatePassword(req.body.currentPass)

        if (passwordInvalid) formErrors.push({
            fieldName: 'currentPass',
            message: passwordInvalid
        })

        if(formErrors.length) return res.render('dashboard/settingsView', { formErrors: formErrors })

        if (await req.prisma.user.count({
            where: {
                email: req.body.newEmail
            }
        }) > 0) formErrors.push({
            fieldName: 'newEmail',
            message: 'This Email is already used by another account'
        })

        const user = await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        })

        if(req.body.currentPass !== user!.password) formErrors.push({ fieldName: 'currentPass', message:'Current password does not match.' })


        if(formErrors.length) return res.render('dashboard/settingsView', { formErrors: formErrors })

        //validation ok
        try {
            const authCode = Math.floor(Math.random() * (99999999 - 1) + 1).toString()

            await emailService.sendEmail(req.body.newEmail, 'Verify Your Email Address', 'changeEmail', { newEmail: req.body.newEmail,username: user!.username, code: authCode })
    
            await req.prisma.user.update({
                data: {
                    authCode: authCode,
                    newUnconfirmedEmail: req.body.newEmail
                },
                where: {
                    username: user!.username
                }
            })
            res.render('dashboard/settingsView', { confirmChangeEmail: true })
        } catch (error) {
            console.error(error)
            formErrors.push({ fieldName: 'newEmail', message:'Something went wrong Please try again later' })
            res.render('dashboard/settingsView', { formErrors: formErrors })
        }
        } else if (req.body.action === 'confirmChangeEmail' && (await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        }))!.newUnconfirmedEmail !== null){

        let formErrors: formError[] = []

        const user = await req.prisma.user.findFirst({
            where: {
                username: req.session.loginUser
            }
        })

        if (user!.authCode !== req.body.code) formErrors.push({ fieldName: 'code', message: 'The code you entered is invalid' })


        if (await req.prisma.user.count({
            where: {
                email: user!.newUnconfirmedEmail as string
            }
        }) > 0) formErrors.push({
            fieldName: 'code',
            message: 'This Email is already used by another account'
        })

        if(formErrors.length) return res.render('dashboard/settingsView', { formErrors: formErrors, confirmChangeEmail: true })

        const result = await req.prisma.user.update({
            where: {
                username: req.session.loginUser
            },
            data: {
                email: user!.newUnconfirmedEmail as string,
                authCode:null,
                newUnconfirmedEmail: null
            }
        })


        res.render('dashboard/settingsView', { successMessage: `Your email has been changed to ${result!.email}` })
    }
}