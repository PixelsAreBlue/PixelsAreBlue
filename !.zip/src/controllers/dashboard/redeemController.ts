import express from 'express'
import { formError } from '../../types/types'
import RecaptchaClient from '../../utils/RecaptchaClient'

export async function doGetCatalog (req: express.Request, res: express.Response) {

    let catalogs:any

    if (req.query.search && req.query.search.length && typeof req.query.search === 'string') {
        catalogs = await req.prisma.rewardCatalog.findMany({
            where: {
                title: {
                    search: req.query.search.replace(' ', ' | ')
                }
            }
        })
    } else {
        catalogs = await req.prisma.rewardCatalog.findMany({
            where: {
                isDeleted: false
            }
        })
    }

    for (let catalog of catalogs){
        const subItems = await req.prisma.rewardItem.findMany({
            where: {
                catalogID: catalog.id,
                isDeleted: false
            }
        })

        catalog.minimumCost = 99999999999999999999999999999999999999999999
        for(let subItem of subItems){
            catalog.minimumCost = catalog.minimumCost as number 
            if(subItem.costPoint < catalog.minimumCost) catalog.minimumCost = subItem.costPoint as number
        }
    }

    res.render('dashboard/redeem/catalogView', { catalogs: catalogs })
}

export async function doGetRedeem (req: express.Request, res: express.Response) { 

    if (!req.params.catalogID  || !req.params.catalogID.length || !parseInt(req.params.catalogID)) {
        return res.redirect('/dashboard/redeem')
    }

    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: parseInt(req.params.catalogID),
            isDeleted: false
        }
    })
    if(!catalog) return res.redirect('/dashboard/redeem')
    const items = await req.prisma.rewardItem.findMany({
        where: {
            catalogID: catalog.id,
            isDeleted: false
        }
    })
    
    res.render('dashboard/redeem/redeemView', { catalog: catalog, items: items, csrfToken: req.csrfToken() })
}
export async function doPostRedeem (req: express.Request, res: express.Response) {

    if (!req.params.catalogID  || !req.params.catalogID.length || !parseInt(req.params.catalogID)) {
        return res.redirect('/dashboard/redeem')
    }

    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: parseInt(req.params.catalogID),
            isDeleted: false
        }
    })
    if(!catalog) return res.redirect('/dashboard/redeem')

    let errors = []

    const items = await req.prisma.rewardItem.findMany({
        where: {
            catalogID: catalog.id,
            isDeleted: false
        }
    })

    const item = await req.prisma.rewardItem.findFirst({
        where: {
            catalogID: catalog.id,
            id: parseInt(req.body.subItem),
            isDeleted: false
        }
    })
    if(!item) errors.push({ message:'subItem is invalid' })

    if (catalog.customField) {
        if (!req.body.customField || !req.body.customField.length) {
            errors.push ({ message: `${catalog.customField} must not be empty` })
        }
        if (req.body.customField.length > 70) {
            errors.push({ message: `${catalog.customField} must be 70 characters or less` })
        }
    }
        
    const user = await req.prisma.user.findFirst({
        where: {
            username: req.session.loginUser
        }
    })

    if(user!.balance! < item!.costPoint) { 
        errors.push({message:'You don\'t have a sufficient balance to claim this reward' })
    }
    if(errors.length) return res.render('dashboard/redeem/redeemView', { errors: errors, catalog: catalog, items: items, csrfToken: req.csrfToken() }) 


    await req.prisma.$transaction([
        req.prisma.rewardOrder.create({
            data: {
                username: user!.username,
                status: 'onHold',
                itemID: item!.id,
                customFieldValue: req.body.customField && req.body.customField.length ? req.body.customField : null
            }
        }),
        req.prisma.user.update({
            where: {
                username: user!.username
            },
            data: {
                balance: {
                    decrement: item!.costPoint
                }
            }
        })
    ])
    res.render('dashboard/redeem/redeemView', { 
        successMessage: 'You have successfully requested a reward. We will send you an email as soon as the your reward is ready', 
        catalog: catalog, items: items, csrfToken: req.csrfToken() }) 

}

export async function doGetSuggest(req: express.Request, res: express.Response) {
    res.render('dashboard/redeem/suggestView')
}
export async function doPostSuggest(req: express.Request, res: express.Response) {
    const formErrors: formError[] = []
    if(!await RecaptchaClient.verifyRecaptchaToken(req.body['g-recaptcha-response'])) formErrors.push({ fieldName: 'name', message:'captcha error' })
    if(!req.body['name'] || !req.body['name'].length) formErrors.push({ fieldName: 'name', message:'Name must not be empty' })
    if(!req.body['website'] || !req.body['website'].length) formErrors.push({ fieldName: 'website', message:'Website must not be empty' })
    if(!req.body['region'] || !req.body['region'].length) formErrors.push({ fieldName: 'region', message:'Region must not be empty' })
    if(!req.body['description'] || !req.body['description'].length) formErrors.push({ fieldName: 'description', message:'Description must not be empty' })
    if(formErrors.length) return res.render('dashboard/redeem/suggestView', { formErrors: formErrors })

    await req.prisma.rewardSuggest.create({
        data: {
            username: req.session.loginUser,
            rewardName: req.body['name'],
            website: req.body['website'],
            region: req.body['region'],
            description: req.body['description']
        }
    })

    res.render('dashboard/redeem/suggestView', { successMessage: 'Thank you for the feedback' })
}