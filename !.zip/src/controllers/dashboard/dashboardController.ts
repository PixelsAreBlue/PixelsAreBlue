import express from 'express'
import RecaptchaClient from '../../utils/RecaptchaClient'

export async function doGetDashboard (req: express.Request, res: express.Response) {
    const query = await req.prisma.jackpotHistory.findFirst({
        where: {
            username: req.session.loginUser,
            createdAt: {
                gte: new Date(new Date().setDate(new Date().getDate() - 1))
            }
        }
    })

    const jackpotLeft = query ? new Date(new Date(query!.createdAt.setDate(query!.createdAt.getDate() + 1)).getTime() - new Date().getTime()).toUTCString().match(/..:..:../)![0] : null


    res.render('dashboard/dashboardView', {
        jackpotLeft: jackpotLeft
    }) 
}

export async function doPostDashboard (req: express.Request, res: express.Response) {

    if (req.body.action === 'claimJackpot') {
        if(!await RecaptchaClient.verifyRecaptchaToken(req.body['g-recaptcha-response'])){
            return res.json({
                ok: false,
                message: 'captcha error'
            })
        }
        if ( await req.prisma.jackpotHistory.count({
            where: {
                username: req.session.loginUser,
                createdAt: {
                    gte: new Date(new Date().setDate(new Date().getDate() - 1))
                }
            }
        }) > 0) {
            return res.json({
                ok: false,
                message: 'You have already rolled a jackpot today'
            })
        }

        let reward = 5

        const n = Math.random()

        if (n < 0.5) {
            reward = 10
        } else if (n < 0.3) {
            reward = 50
        } else if (n < 0.003) {
            reward = 100
        } else if (n < 0.001) {
            reward = 600
        } else if (n < 0.0009) {
            reward = 9999
        }

        await req.prisma.$transaction([
            prisma.jackpotHistory.create({
                data: {
                    username: req.session.loginUser,
                    points: reward
                }
            }),
            prisma.user.update({
                where: {
                    username: req.session.loginUser
                },
                data: {
                    balance: {
                        increment: reward
                    }
                }
            })
        ])

        res.json({
            ok: true,
            reward: reward
        })
    }
}

export async function doGetInvite (req: express.Request, res: express.Response) {
    const referralCount = await req.prisma.user.count({
        where: {
            referrer: req.session.loginUser
        }
    })
    const g = await req.prisma.user.findMany({
        orderBy: {
            updatedAt: 'desc'
        },
        where: {
            referrer: req.session.loginUser
        },
        take: 30
    })


    let guests: any = []

    for (const guest of g){ 
        const offerCount = await req.prisma.offerHistory.count({
            where: {
                username: guest.username
            }
        })

        guests.push({
            username: guest.username,
            createdAt: guest.createdAt,
            completedOffers: offerCount
        })
    }


    res.render('dashboard/inviteView', { referralCount: referralCount, guests: guests })
}


type activityAction = 'credit'|'reversal'

interface activityInterface {
    points: number,
    action: activityAction,
    tags: string[],
    timestamp: string | Date
}

export async function doGetActivity (req: express.Request, res: express.Response) {

    let payouts: any = await req.prisma.rewardOrder.findMany({
        where: {
            username: req.session.loginUser
        },
        orderBy: {
            updatedAt: 'desc'
        },
        take: 5
    })

    for (let payout of payouts) {
        payout.subItem = await req.prisma.rewardItem.findFirst({
            where: {
                id: payout.itemID
            }
        })
    }

    res.render('dashboard/activityView', {
        payouts: payouts,
        loginLogs: await req.prisma.loginLog.findMany({
            where: {
                username: req.session.loginUser
            },
            orderBy: {
                timestamp: 'desc'
            },
            take: 5
        })
    })
}
export async function doGetFetchActivity (req: express.Request, res: express.Response) {
    let activities: activityInterface[] = []
    const offers = await req.prisma.offerHistory.findMany({
        where: {
            username: req.session.loginUser
        }
    })
    offers.forEach(function  (offer) {
        activities.push({
            points: offer.points,
            action: offer.action,
            tags: [offer.provider as string, 'Offer'],
            timestamp: offer.createdAt
        })
    })
    const referrals = await req.prisma.referralHistory.findMany({
        where: {
            referrerUsername: req.session.loginUser
        }
    })
    referrals.forEach( function (referral) {
        activities.push({
            points: referral.commissionPoints as number,
            action: 'credit',
            tags: ['Income from Referral'],
            timestamp: referral.createdAt
        })
    })

    const promotions = await req.prisma.promotionHistory.findMany({
        where: {
            username: req.session.loginUser
        }
    })

    promotions.forEach ( function (promotion) {
        activities.push({
            points: promotion.points,
            action: 'credit',
            tags: ['Special Promotion', promotion.promotionName],
            timestamp: promotion.createdAt
        })
    })

    const promoCodes = await req.prisma.promoCodeHistory.findMany({
        where: {
            username: req.session.loginUser
        }
    })

    for(const promo of promoCodes) {
        const p = await req.prisma.promoCode.findFirst({
            where: {
                code: promo.code
            }
        })
        activities.push({
            points: p!.points!,
            action: 'credit',
            tags: ['Promotional Code', promo!.code!],
            timestamp: promo!.createdAt!
        })
    }


    const jackpots = await req.prisma.jackpotHistory.findMany({
        where: {
            username: req.session.loginUser
        }
    })

    for (const jackpot of jackpots) {
        activities.push({
            points: jackpot.points,
            action: 'credit',
            tags: ['Daily Jackpot'],
            timestamp: jackpot.createdAt
        })
    }

    activities = activities.sort(function (a, b){
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    })


    if (req.query.page === 'all') {
        return res.json({
            data: activities
        })
    }

    const start = 10 * parseInt(req.query.page as string) || 0
    const end = start + 10

    res.json({
        pagesTotal: Math.trunc(activities.length / 10),
        data:activities.slice(start, end)
    })
}