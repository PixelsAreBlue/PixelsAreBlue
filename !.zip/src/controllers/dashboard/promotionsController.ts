import express from 'express'
import { default as config } from '../../config.json'
import fetch from 'node-fetch'
import { formError } from '../../types/types'

export async function doGetPromotions (req: express.Request, res: express.Response) {
    res.render('dashboard/promotionsView', { claimable: { discord: await isClaimable('discord', req.session.loginUser) } })
}

export async function doPostPromotions (req: express.Request, res: express.Response) {
    let formErrors: formError[] = []
    if (!req.body.promoCode || !req.body.promoCode.length) formErrors.push({ fieldName: 'promoCode', message: 'Code must not be empty' })

    const query = await req.prisma.promoCode.findFirst({
        where: {
            code: req.body.promoCode
        }
    })

    // 1. Basic Validation
    if (!query) { 
        formErrors.push({ fieldName: 'promoCode', message: 'Code doesn\'t exist.' })
    }
    if (query && query!.isExpired){ 
        formErrors.push({ fieldName: 'promoCode', message: 'This code has expired' })
    }

    // 2. Confirm that the user is new to using this promo code
    if (await req.prisma.promoCodeHistory.count({
        where: {
            code: req.body.promoCode,
            username: req.session.loginUser
        }
    }) > 0){
        formErrors.push({ fieldName: 'promoCode', message: 'Code already redeemed' })
    }

    // 3. Check if the code has out of expiry date
    if (query && query!.expiryDate && new Date(query!.expiryDate).getTime() < new Date().getTime()) {
        await req.prisma.promoCode.update({
            where: {
                code: req.body.promoCode
            },
            data: {
                isExpired: true
            }
        })
        formErrors.push({ fieldName: 'promoCode', message: 'This code has expired' })
    }
    if (formErrors.length) return res.render('dashboard/promotionsView', { claimable: { discord: await isClaimable('discord', req.session.loginUser) }, formErrors: formErrors})

    // 4. process transaction


    await req.prisma.$transaction([
        req.prisma.user.update({
            where: {
                username: req.session.loginUser
            },
            data: {
                balance: {
                    increment: query!.points
                }
            }
        }),
        req.prisma.promoCodeHistory.create({
            data: {
                code: query!.code,
                username: req.session.loginUser
            }
        })
    ])

    // 5. Check if the code has reached max use
    if (query!.maxUse! && await req.prisma.promoCodeHistory.count({
        where: {
            code: query!.code
        }
    }) >= query!.maxUse!){
        await req.prisma.promoCode.update({
            where: {
                code: req.body.promoCode
            },
            data: {
                isExpired: true
            }
        })
    }
    res.render('dashboard/promotionsView', { claimable: { discord: await isClaimable('discord', req.session.loginUser) }, successMessage: `${query!.points} points have been added to your account balance` })

}

export async function doGetDiscord (req: express.Request, res: express.Response) {

    //* 1. Check if the user is new to redeem this promotion *//
    if (!await isClaimable('discord', req.session.loginUser)) {
        return res.status(403).send('You have already claimed this promotion')
    }

    if(!req.query.code || !req.query.code.length) {
        return res.send(`
        <script>
            (function() {
                window.opener.discordCallback(false)
                window.close()
            }())
        </script>
        `)
    }

    // 2. Call to the Discord API and Get Access Token

    const getTokens = async function ():Promise<any> {
        let params = new URLSearchParams()
        params.set("grant_type", "authorization_code")
        params.set("code", `${req.query.code}`)
        params.set("redirect_uri", `${config.baseURL.protocol}://${config.baseURL.host}/dashboard/promotions/claim/discord`)
        params.set("client_id", `${config.discord.oauth2.clientId}`)
        params.set("client_secret", `${config.discord.oauth2.clientSecret}`)
        const response = await fetch('https://discordapp.com/api/oauth2/token', {
            method: "POST",
            body:  params.toString(),
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            }
        })
        const json: any = await response.json()
        if (!response.ok) {
            await wait(json.retry_after || 10000)
            return await getTokens()
        } else {
            return json
        }
    }
    const tokens = await getTokens()
    if (!tokens.access_token || !tokens.access_token.length){
        return res.send(`
        <script>
            (function() {
                window.opener.discordCallback(false)
                window.close()
            }())
        </script>
        `)
    }

    // 3. Fetch Guilds using Access Token 
    const getGuilds = async function ():Promise<any> {
        const response = await fetch("https://discordapp.com/api/users/@me/guilds", {
            method: "GET",
            headers: { Authorization: `Bearer ${tokens.access_token}` }
        })
        const json: any = await response.json()
        if (!response.ok) {
            await wait(json.retry_after || 10000)
            return await getGuilds()
        } else {
            return json
        }
    }
    const guilds = await getGuilds()
    const guild = guilds.filter(function (g:any){
        return g.id === config.discord.supportServerId
    })


    // 4. Check if the user already on the server
    if(guild.length) {

        // 5. Process Transaction
        await claimPromotion('discord', req.session.loginUser, 100)
        return res.send(`
        <script>
            (function() {
                window.opener.discordCallback(true)
                window.close()
            }())
        </script>
        `)
    } else {
        const getUser = async function ():Promise<any> {
            const response = await fetch("https://discordapp.com/api/users/@me", {
                method: "GET",
                headers: { Authorization: `Bearer ${tokens.access_token}` }
            })
            const json: any = await response.json()
            if (!response.ok) {
                await wait(json.retry_after || 10000)
                return await getUser()
            } else {
                return json
            }
        }
        const user = await getUser()
        const addGuild = async function ():Promise<any> {
            const response = await fetch(`https://discord.com/api/v9/guilds/${config.discord.supportServerId}/members/${user.id}`, {
                method: "PUT",
                body:  JSON.stringify({ access_token: tokens.access_token }),
                headers: { Authorization: `Bot ${config.discord.botToken}`, 'Content-type': 'application/json' }
            })
            let json:any = {}
            if(response.statusText !== 'No Content') {
                json = await response.json()
            }
            if (!response.ok) {
                await wait(json.retry_after || 10000)
                return await addGuild()
            } else {
                return json
            }
        }
        if (await addGuild()) {
            // 5. Process Transaction
            await claimPromotion('discord', req.session.loginUser, 100)
            return res.send(`
            <script>
                (function() {
                    window.opener.discordCallback(true)
                    window.close()
                }())
            </script>
            `)
        }
    }

}


function wait (seconds:number){
    return new Promise<void>((resolve, reject) => {
        const ms = seconds * 1000 /* convert seconds to milliseconds */
        setTimeout(( () => {
            resolve()
        }), ms)
    })
}

async function claimPromotion (promotionName: string, username: string, points: number) {
    const user = await global.prisma.user.findFirst({
        where: {
            username: username
        }
    })
    if(!user) throw new Error('User must exist') // user must exist
    

    await global.prisma.$transaction([
        global.prisma.user.update({
            where: {
                username: username
            },
            data: {
                balance: {
                    increment: points
                }
            }
        }),
        global.prisma.promotionHistory.create({
            data: {
                promotionName: promotionName,
                username: username,
                points: points
            }
        })
    ])
}

async function isClaimable (promotionName: string, username: string) {
    const query = await global.prisma.promotionHistory.count({
        where: {
            username: username,
            promotionName: promotionName, 
        }
    })
    return query === 0
}