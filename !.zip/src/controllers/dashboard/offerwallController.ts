import express from 'express'

export function doGetOfferwall (req: express.Request, res: express.Response) {
    let offerwall: any = null 
    res.locals.Offerwalls.forEach( function (wall: any) {
        if (wall.id === req.params.offerwallId) offerwall = wall
    })
    if(!offerwall) return res.redirect('/dashboard/offerwalls')

    res.render('dashboard/offerwall/offerwallView', { Offerwall: offerwall })
}
export function doGetOfferwalls (req: express.Request, res:express.Response){
    res.render('dashboard/offerwall/offerwallsView')
}

export function doGetVideoWalls (req: express.Request, res: express.Response) {
    res.render('dashboard/offerwall/videowallsView')
}