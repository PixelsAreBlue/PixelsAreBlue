import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
    Bitlabs Server to Server Callback
    https://bitlabs.ai/integrations/server-to-server-callback
*/

export default class BitlabsController extends Base {
    public constructor () {
        super({ providerName: 'bitlabs' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const secretKey = config.apikeys.bitlabs.secretKey
        const hash = req.query['hash']
        const reward = req.query['val']
        const username = req.query['uid']
        const transactionId = req.query['txid']
        const url = `https://${config.baseURL.host}${req.originalUrl}`

        if(!secretKey || !hash || !reward || !username || !transactionId) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('There are missing parameters')
        }

        const splitUrl = url.split('&hash=')
        const hmac = CryptoJS.enc.Hex.stringify(CryptoJS.HmacSHA1(splitUrl[0], secretKey))
       // validate Hash
        if(hash !== hmac){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('Signature doesn\'t match')
        }
        if(await req.prisma.user.count({
            where: {
                username: username as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('User not exist')
        }
        if(!await super.isNewTransaction(transactionId as string)){
            super.errorLogger('duplicate transaction', req)
            return res.status(400).send('duplicate transaction') 
        }
        await super.addBalance(username as string, Math.abs(parseInt(reward as string)), transactionId as string)
        super.infoLogger(transactionId as string, req)
        res.send('OK')
    }
}