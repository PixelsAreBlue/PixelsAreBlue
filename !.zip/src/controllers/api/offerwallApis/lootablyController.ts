import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
Lootably Postback API
Docs at https://dashboard.lootably.com/
*/

export default class LootablyController extends Base {
    public constructor () {
        super({ providerName: 'lootably' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const secret = config.apikeys.lootably.postbackSecret 
        const userId = req.query['userID']
        const ip = req.query['ip']
        const transactionId = req.query['transactionID']
        const revenue = req.query['revenue']
        const reward = req.query['currencyReward']
        const status = req.query['status']
        const hash = req.query['hash']

        if(!userId || !transactionId || !ip || !reward || !status || !hash) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('0')
        }

        const uniqueTransactionId = status === '1' ? `${transactionId}.complete` : `${transactionId}.chargeback` // add prefix for charge back transaction

        if(CryptoJS.SHA256(`${userId}${ip}${revenue}${reward}${secret}`).toString() !== hash){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('0')
        }
        if(await req.prisma.user.count({
            where: {
                username: userId as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('0')
        }
        if(!await super.isNewTransaction(`${uniqueTransactionId}`)){ 
            super.errorLogger('Duplicate Transaction', req)
            return res.status(400).send('0') 
        }
        if (status === '1') {
            await super.addBalance(userId as string, Math.abs(parseInt(reward as string)), uniqueTransactionId)
        }else if (status === '2') {
            await super.reduceBalance(userId as string, Math.abs(parseInt(reward as string)), uniqueTransactionId)
        }
        super.infoLogger(uniqueTransactionId as string, req)
        res.send('1')
    }
}