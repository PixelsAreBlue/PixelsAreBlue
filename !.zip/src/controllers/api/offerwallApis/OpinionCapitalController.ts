import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
Opinion Capital Postback API
Docs at https://publishers.opinioncapital.com/
*/

export default class OpinionCapitalController extends Base {
    public constructor () {
        super({ providerName: 'opinionCapital' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const secret = config.apikeys.opinionCapital.postbackSecret
        const userId = req.query['username']
        const transId = req.query['clickid']
        const status = req.query['status']
        const reward = req.query['usereward']
        const hash = req.query['hash']
        const offerNumber = req.query['offernumber']


        if(!userId || !transId || !status || !reward || !hash || !offerNumber) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('error')
        }
        if(CryptoJS.SHA1(`${offerNumber}${userId}${transId}${status}${reward}${secret}`).toString() !== hash){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('error')
        }

        const uniqueTransactionId = status === '1' ? `${transId}.complete` : `${transId}.reversal` // add prefix for reversal transaction


        if(await req.prisma.user.count({
            where: {
                username: userId as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('error')
        }
        if(!await super.isNewTransaction(uniqueTransactionId)){ 
            super.errorLogger('Duplicate Transaction', req)
            return res.status(400).send('error') 
        }
        if (status === '1') {
            await super.addBalance(userId as string, Math.abs(parseInt(reward as string)), uniqueTransactionId)
        }else if (status === '2') {
            await super.reduceBalance(userId as string, Math.abs(parseInt(reward as string)), uniqueTransactionId)
        }

        super.infoLogger(uniqueTransactionId, req)
        res.send('ok')
    }
}