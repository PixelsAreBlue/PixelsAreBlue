import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
    CPX Research Postback API
    https://publisher.cpx-research.com/
*/

export default class CpxController extends Base {
    public constructor () {
        super({ providerName: 'cpxResearch' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const securityHash = config.apikeys.cpxResearch.securityHash
        const action = req.query['status'] // (1 = completed 2 = canceled)
        const transId = req.query['trans_id']
        const userId = req.query['user_id']
        const amountLocal = req.query['amount_local'] // amount in local currency
        const secureHash = req.query['hash']

        /*
            According to customer support, CPX will call the same postback with same transaction ID when the status is changed to status=2
        */
        const uniqueTransactionId = action === '1' ? transId+'.completed' : transId+'.canceled' // You have to add a prefix to keep the transaction Id unique
        if(!action || !transId || !userId || !amountLocal || !secureHash) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('There are missing parameters')
        }
       // validate Hash
        if(CryptoJS.MD5(`${transId}-${securityHash}`).toString() !== secureHash){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('Signature doesn\'t match')
        }

        if(await req.prisma.user.count({
            where: {
                username: userId as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('User not exist')
        }
        if(!await super.isNewTransaction(uniqueTransactionId as string)){ // Check if the transaction is new
            super.errorLogger('Transaction already exists', req)
            return res.status(400).send('Transaction already exists')
        }

        if(action === '1') { // action = 1 CREDITED // action = 2 REVOKED
            await super.addBalance(userId as string, Math.abs(parseInt(amountLocal as string)), uniqueTransactionId)
        } else if (action === '2') {
            await super.reduceBalance(userId as string, Math.abs(parseInt(amountLocal as string)), uniqueTransactionId)
        }
        super.infoLogger(uniqueTransactionId as string, req)
        return res.send('OK')
    }
}