import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
    KiwiWall Postback API
    https://www.kiwiwall.com/postback-documentation
*/

export default class KiwiwallController extends Base {
    public constructor () {
        super({ providerName: 'kiwiwall' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const secretKey = config.apikeys.kiwiwall.secretKey

        const status = req.query['status']
        const transId = req.query['trans_id']
        const subId = req.query['sub_id']
        const amount = req.query['amount']
        const signature = req.query['signature']
        if(!status || !transId || !subId || !amount || !signature) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('0')
        }
        // Create validation signature
        const validationSignature = CryptoJS.MD5(`${subId}:${amount}:${secretKey}`).toString()
        if(signature !== validationSignature) {
            super.errorLogger('signature does not match', req)
            // Signatures not equal - send error code
            return res.status(400).send('0')
        }
        if(await req.prisma.user.count({
            where: {
                username: subId as string
            }
        }) <= 0) {
            super.errorLogger('user not exist', req)
            return res.status(400).send('0')
        }
        if(!await super.isNewTransaction(transId as string)){ // Check if the transaction is new
            super.errorLogger('duplicate transaction', req)
            //If the transaction already exist - send error code
            return res.status(400).send('0') 
        }
        // Validation was successful. Credit user process.
        if (status === '1') {
            await super.addBalance(subId as string, Math.abs(parseInt(amount as string)), transId as string)
        } else if (status === '2') {
            await super.reduceBalance(subId as string, Math.abs(parseInt(amount as string)), transId as string)
        }
        super.infoLogger(transId as string, req)
        res.send('1')
    }
}