import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
Wannads Postback API
Docs at https://affiliates.wannads.com/documentation/postback_notifications
*/

export default class WannadsController extends Base {
    public constructor () {
        super({ providerName: 'wannads' })
    }
    public async doGet (req: express.Request, res: express.Response) {
        const secret = config.apikeys.wannads.secret
        const username = req.query['subId']
        const transactionId = req.query['transId']
        const points = req.query['reward']
        const signature = req.query['signature']
        const action = req.query['status']
        const whitelistIps = ['34.250.159.173', '34.244.210.150', '52.212.236.135', '34.251.83.149']


        if(!secret || !username || !transactionId || !points || !signature || !action) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('There are missing parameters')
        }
        if(process.env.NODE_ENV === 'production' && !whitelistIps.includes(req.ip)){
            super.errorLogger('Caller IP is not in the whitelist', req)
            return res.status(403).send('Your IP is not in the whitelist')
        }
        // validate signature
        if(CryptoJS.MD5(`${username}${transactionId}${points}${secret}`).toString() !== signature){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('Signature doesn\'t match')
        }
        if(await req.prisma.user.count({
            where: {
                username: username as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('User not exist')
        }
        if(!await super.isNewTransaction(transactionId as string)){ // Check if the transaction is new
            super.errorLogger('Duplicate Transaction', req)
            return res.status(400).send('DUP') // If the transaction already exist please echo DUP.
        }
        if (action === '1') { // action = 1 CREDITED // action = 2 REVOKED
            await super.addBalance(username as string, Math.abs(parseInt(points as string)), transactionId as string)
        }else if (action === '2') {
            await super.reduceBalance(username as string, Math.abs(parseInt(points as string)), transactionId as string)
        }
        super.infoLogger(transactionId as string, req)
        res.send('OK')
    }
}