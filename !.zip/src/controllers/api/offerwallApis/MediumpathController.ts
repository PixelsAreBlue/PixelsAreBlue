import express from 'express'
import Base from '../../../base/api/BaseOfferwallApi'
import { default as config } from '../../../config.json'
import CryptoJS from 'crypto-js'

/*
MediumPath Postback API
Docs at https://www.mediumpath.com/documentation
*/

export default class MediumpathController extends Base {
    public constructor () {
        super({ providerName: 'mediumPath' })
    }
    public async doPost (req: express.Request, res: express.Response) {
        const secret = config.apikeys.mediumpath.secretKey 
        const userId = req.body['user_id']
        const transId = req.body['transId']
        const status = req.body['status']
        const reward = req.body['reward']
        const signature = req.body['signature']
        if(!userId || !transId || !status || !reward || !signature) {
            super.errorLogger('There are missing parameters', req)
            return res.status(400).send('error')
        }
        if(CryptoJS.MD5(`${userId}${transId}${reward}${secret}`).toString() !== signature){
            super.errorLogger('Signature doesn\'t match', req)
            return res.status(400).send('error')
        }
        if(await req.prisma.user.count({
            where: {
                username: userId as string
            }
        }) <= 0) {
            super.errorLogger('User not exist', req)
            return res.status(400).send('error')
        }
        if(!await super.isNewTransaction(transId as string)){ 
            super.errorLogger('Duplicate Transaction', req)
            return res.status(400).send('error') 
        }
        if (status === 'SUCCESS') {
            await super.addBalance(userId as string, Math.abs(parseInt(reward as string)), transId as string)
        }else if (status === 'ERROR') {
            await super.reduceBalance(userId as string, Math.abs(parseInt(reward as string)), transId as string)
        }
        super.infoLogger(transId as string, req)
        res.send('ok')
    }
}