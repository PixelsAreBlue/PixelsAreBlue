import express from 'express'
import pagination from '../../utils/admin/pagination'

export async function doGetUsers(req: express.Request, res: express.Response) {
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.user,
        [
            {
                ColumnName: "username",
                type: "String"
            },
            {
                ColumnName: "email",
                type: "String"
            },
            {
                ColumnName: "password",
                type: "String"
            },
            {
                ColumnName: "balance",
                type: "Int"
            },
            {
                ColumnName: "referrer",
                type: "String"
            },
            {
                ColumnName: "authCode",
                type: "String"
            },
            {
                ColumnName: "isAdmin",
                type: "Boolean"
            },
            {
                ColumnName: "isBanned",
                type: "Boolean"
            },
            {
                ColumnName: "isEmailVerified",
                type: "Boolean"
            }
        ]
    )
    res.render('admin/user/usersView')
}

export async function doGetUser(req: express.Request, res: express.Response) {   
    const userData = await req.prisma.user.findFirst({
        where: {
            username: req.params.username
        }
    })
    if(!userData) return res.redirect('/admin/user-management')
    res.render('admin/user/userView', {
        userData: userData,
        infos: {
            referredUsers: await req.prisma.user.findMany({
                where: {
                    referrer: req.params.username
                },
                orderBy: {
                    updatedAt: 'desc'
                },
                take: 10
            }),
            loginLogs: await req.prisma.loginLog.findMany({
                where: {
                    username: req.params.username
                },
                orderBy: {
                    timestamp: 'desc'
                },
                take: 10
            }),
            offers: await req.prisma.offerHistory.findMany({
                where: {
                    username: req.params.username
                },
                orderBy: {
                    updatedAt: 'desc'
                },
                take: 10
            })
        },
        counts: {
            referredUsers: await req.prisma.user.count({
                where: {
                    referrer: req.params.username
                }
            }),
            offers: await req.prisma.offerHistory.count({
                where: {
                    username: req.params.username
                }
            })
        }
    })
}
export async function doPostUser (req: express.Request, res: express.Response) {
    const userData = await req.prisma.user.findFirst({
        where: {
            username: req.params.username
        }
    })

    if(!userData) return res.redirect('/admin/user-management')

    if (req.body.action === "balance") {
        if (req.body.balanceAction === 'add'){
            await req.prisma.user.update({
                where: {
                    username: userData.username
                },
                data: {
                    balance: {
                        increment: parseInt(req.body.value)
                    }
                }
            })
        } else if (req.body.balanceAction === 'reduce') {
            await req.prisma.user.update({
                where: {
                    username: userData.username
                },
                data: {
                    balance: {
                        decrement: parseInt(req.body.value)
                    }
                }
            })
        }
    
        res.render('admin/user/userView', {
            userData: userData,
            successMessage: 'The Balance has been updated',
            infos: {
                referredUsers: await req.prisma.user.findMany({
                    where: {
                        referrer: req.params.username
                    },
                    orderBy: {
                        updatedAt: 'desc'
                    },
                    take: 10
                }),
                loginLogs: await req.prisma.loginLog.findMany({
                    where: {
                        username: req.params.username
                    },
                    orderBy: {
                        timestamp: 'desc'
                    },
                    take: 10
                }),
                offers: await req.prisma.offerHistory.findMany({
                    where: {
                        username: req.params.username
                    },
                    orderBy: {
                        updatedAt: 'desc'
                    },
                    take: 10
                })
            },
            counts: {
                referredUsers: await req.prisma.user.count({
                    where: {
                        referrer: req.params.username
                    }
                }),
                offers: await req.prisma.offerHistory.count({
                    where: {
                        username: req.params.username
                    }
                })
            }
        })
    }  else if (req.body.action === "statues") {
        await req.prisma.user.update({
            where: {
                username: userData.username
            },
            data: {
                isEmailVerified: req.body.isEmailVerified && req.body.isEmailVerified.length ? true : false,
                isAdmin: req.body.isAdmin && req.body.isAdmin.length ? true : false,
                isBanned: req.body.isBanned && req.body.isBanned.length ? true : false
            }
        })
        
        res.render('admin/user/userView', {
            userData: userData,
            successMessage: 'The statuses has been updated',
            infos: {
                referredUsers: await req.prisma.user.findMany({
                    where: {
                        referrer: req.params.username
                    },
                    orderBy: {
                        updatedAt: 'desc'
                    },
                    take: 10
                }),
                loginLogs: await req.prisma.loginLog.findMany({
                    where: {
                        username: req.params.username
                    },
                    orderBy: {
                        timestamp: 'desc'
                    },
                    take: 10
                }),
                offers: await req.prisma.offerHistory.findMany({
                    where: {
                        username: req.params.username
                    },
                    orderBy: {
                        updatedAt: 'desc'
                    },
                    take: 10
                })
            },
            counts: {
                referredUsers: await req.prisma.user.count({
                    where: {
                        referrer: req.params.username
                    }
                }),
                offers: await req.prisma.offerHistory.count({
                    where: {
                        username: req.params.username
                    }
                })
            }
        })
    }
}

export async function doGetLoginLogs(req: express.Request, res: express.Response) {
    await pagination(
        req,
        res,
        'timestamp',
        req.prisma.loginLog,
        [
            {
                ColumnName: "username",
                type: "String"
            },
            {
                ColumnName: "os",
                type: "String"
            },
            {
                ColumnName: "browser",
                type: "String"
            },
            {
                ColumnName: "device",
                type: "String"
            },
            {
                ColumnName: "ip",
                type: "String"
            },
        ]
    )
    res.render('admin/user/loginLogsView')
}