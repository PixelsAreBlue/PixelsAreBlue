import express from 'express' 

import { formError } from '../../types/types'

import EmailService from '../../services/EmailService'

import pagination from '../../utils/admin/pagination'

export async function doGetCatalog (req: express.Request, res: express.Response) {
    const catalogs = await req.prisma.rewardCatalog.findMany({
        where: {
            isDeleted: false
        }
    })
    res.render('admin/reward/catalog/catalogView', { catalogs: catalogs })
}
export async function doGetCatalogAdd (req: express.Request, res: express.Response){
    res.render('admin/reward/catalog/addView')
}
export async function doPostCatalogAdd (req: express.Request, res: express.Response) {
    let formErrors: formError[] = []
    if(!req.body.title || !req.body.title.length) formErrors.push({ fieldName: 'title', message:'Title is required' })

    if(formErrors.length) return res.render('admin/reward/catalog/addView', { formErrors: formErrors })
    
    const query = await req.prisma.rewardCatalog.create({
        data: {
            title: req.body.title,
            description: req.body.description && req.body.description.length ? req.body.description : null,
            bannerImgUrl: req.body.bannerImgUrl && req.body.bannerImgUrl.length ? req.body.bannerImgUrl : null,
            customField: req.body.customField && req.body.customField.length ? req.body.customField : null,
            customFieldDescription: req.body.customFieldDescription && req.body.customFieldDescription.length ? req.body.customFieldDescription : null
        }
    })

    if (req.body.subItems && Array.isArray(req.body.subItems)) {
        req.body.subItems.forEach( async function (subItem: any) {
            if(!subItem.displayName || !subItem.displayName.length) return
            if(!subItem.costPoint || !parseInt(subItem.costPoint)) return
            if(!subItem.region || !subItem.region.length) subItem.region = 'Global'

            subItem.costPoint = parseInt(subItem.costPoint)
            if(0 > subItem.costPoint) return

            await req.prisma.rewardItem.create({
                data: {
                    catalogID: query.id,
                    rewardName: subItem.displayName,
                    costPoint: subItem.costPoint,
                    region: subItem.region
                }
            })
        })
    }

    res.redirect('/admin/reward/catalog')
}

export async function doGetCatalogDelete (req: express.Request, res: express.Response) {
    await req.prisma.rewardCatalog.update({
        where: {
            id: parseInt(req.params.catalogID)
        },
        data: {
            isDeleted: true
        }
    })
    res.redirect('/admin/reward/catalog')
}

export async function doGetDeleteSubItem (req: express.Request, res: express.Response) {
    await req.prisma.rewardItem.update({
        where: {
            id: parseInt(req.params.itemID)
        },
        data: {
            isDeleted: true
        }
    })
    res.redirect(`/admin/reward/catalog/edit/${req.params.catalogID}`)
}


export async function doGetCatalogEdit (req: express.Request, res: express.Response) {
    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: parseInt(req.params.catalogID),
            isDeleted: false
        }
    })
    if(!catalog) return res.send('could not find catalog')
    const subItems = await req.prisma.rewardItem.findMany({
        where: {
            catalogID: catalog.id,
            isDeleted: false
        }
    })
    res.render('admin/reward/catalog/editView', { catalog: catalog, items: subItems })
}
export async function doPostCatalogEdit (req: express.Request, res: express.Response) {
    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: parseInt(req.params.catalogID),
            isDeleted: false
        }
    })
    if(!catalog) return res.send('could not find catalog')
    const subItems = await req.prisma.rewardItem.findMany({
        where: {
            catalogID: catalog.id,
            isDeleted: false
        }
    })
    
    let formErrors: formError[] = []
    if(!req.body.title || !req.body.title.length) formErrors.push({ fieldName: 'title', message:'Title is required' })
    if(formErrors.length) return res.render('admin/reward/catalog/editView', { formErrors: formErrors, catalog: catalog, items: subItems })

    await req.prisma.rewardCatalog.update({
        where: {
            id: catalog.id
        },
        data: {
            title: req.body.title,
            description: req.body.description && req.body.description.length ? req.body.description : null,
            bannerImgUrl: req.body.bannerImgUrl && req.body.bannerImgUrl.length ? req.body.bannerImgUrl : null,
            customField: req.body.customField && req.body.customField.length ? req.body.customField : null,
            customFieldDescription: req.body.customFieldDescription && req.body.customFieldDescription.length ? req.body.customFieldDescription : null
        }
    })


    if (req.body.subItems && Array.isArray(req.body.subItems)) {
        req.body.subItems.forEach( async function (subItem: any) {
            if(!subItem.displayName || !subItem.displayName.length) return
            if(!subItem.costPoint || !parseInt(subItem.costPoint)) return
            if(!subItem.region || !subItem.region.length) subItem.region = 'Global'

            subItem.costPoint = parseInt(subItem.costPoint)
            if(0 > subItem.costPoint) return

            await req.prisma.rewardItem.create({
                data: {
                    catalogID: catalog.id,
                    rewardName: subItem.displayName,
                    costPoint: subItem.costPoint,
                    region: subItem.region
                }
            })
        })
    }

    res.redirect(`/admin/reward/catalog/edit/${req.params.catalogID}`)
}

export async function doGetOrder (req: express.Request, res: express.Response) {    
    const order = await req.prisma.rewardOrder.findFirst({
        where: {
            id: parseInt(req.params.orderID)
        }
    })
    if(!order) return res.redirect('/admin/reward/orders')
    const userData = await req.prisma.user.findFirst({
        where: {
            username: order.username
        }
    })
    const item = await req.prisma.rewardItem.findFirst({
        where: {
            id: order.itemID
        }
    })

    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: item!.catalogID
        }
    })

    res.render('admin/reward/orderView', { order: order, userData: userData, item: item, catalog: catalog })
}
export async function doPostOrder (req: express.Request, res: express.Response) {

    const emailService = new EmailService

    const order = await req.prisma.rewardOrder.findFirst({
        where: {
            id: parseInt(req.params.orderID)
        }
    })
    if (!order) return res.redirect('/admin/reward/orders')
    const userData = await req.prisma.user.findFirst({
        where: {
            username: order.username
        }
    })
    const item = await req.prisma.rewardItem.findFirst({
        where: {
            id: order.itemID
        }
    })

    const catalog = await req.prisma.rewardCatalog.findFirst({
        where: {
            id: item!.catalogID
        }
    })

    if (order.status == "completed" && req.body.action === "resend") {
        await emailService.sendEmail(userData!.email, 'Here\'s your Free DropGC Rewards!', 'reward', { username: userData!.username, rewardName: item!.rewardName, content: order.deliveredItem, method: order.deliveryMethod })
        res.render('admin/reward/orderView', { order: order, userData: userData, item: item, catalog: catalog, successMessage: 'A email has been sent' })
    } else if (order.status === "onHold" && req.body.action === "accept") {
        let formErrors: formError[] = []
        if (req.body.deliveryMethod !== "giftcode" && req.body.deliveryMethod !== "url" && req.body.deliveryMethod !== 'direct') {
            formErrors.push({ fieldName: 'deliveredItem', message: 'Delivery Type is invalid' })
        }
        if(req.body.deliveryMethod !== 'direct' && (!req.body.deliveredItem || !req.body.deliveredItem.length)) {
            formErrors.push({ fieldName: 'deliveredItem', message: 'A item must not be empty' })
        }
        if (req.body.deliveryMethod === 'direct' &&(req.body.deliveredItem || req.body.deliveredItem.length) ) {
            formErrors.push({ fieldName: 'deliveredItem', message: 'Direct Method should be no item' })
        }
        if(formErrors.length) return res.render('admin/reward/orderView',{ order: order, userData: userData, item: item, catalog: catalog, formErrors: formErrors })
                    
        await emailService.sendEmail(userData!.email, 'Here\'s your Free DropGC Rewards!', 'reward', { username: userData!.username, rewardName: item!.rewardName, content: req.body.deliveredItem, method: req.body.deliveryMethod })

        await req.prisma.rewardOrder.update({
            where: {
                id: order.id
            },
            data: {
                status: 'completed',
                deliveredItem: req.body.deliveredItem,
                deliveryMethod: req.body.deliveryMethod
            }
        })

        res.render('admin/reward/orderView',{ order: order, userData: userData, item: item, catalog: catalog, successMessage: 'The order has been accepted' })
    } else if (order.status === "onHold" && req.body.action === "reject") {

        await req.prisma.rewardOrder.update({
            where: {
                id: order.id
            },
            data: {
                status: 'rejected'
            }
        })

        res.render('admin/reward/orderView', { order: order, userData: userData, item: item, catalog: catalog, successMessage: 'The order has been rejected' })
    } else if (order.status === "onHold" &&  req.body.action === "refund") {
        await req.prisma.$transaction([
            req.prisma.rewardOrder.update({
                where: {
                    id: order.id
                },
                data: {
                    status: 'refunded'
                }
            }),
            req.prisma.user.update({
                where: {
                    username: userData!.username
                },
                data: {
                    balance: { 
                        increment: item!.costPoint
                    }
                }
            })
        ])
        res.render('admin/reward/orderView', { order: order, userData: userData, item: item, catalog: catalog, successMessage: 'The order has been refunded' })
    }
}

export async function doGetOrders (req: express.Request, res: express.Response) {    
    await pagination (
        req,
        res,
        'updatedAt',
        req.prisma.rewardOrder,
        [
            {
                ColumnName: 'username',
                type: 'String'
            },
            {
                ColumnName: 'status',
                type: 'String'
            },
            {
                ColumnName: 'deliveredItem',
                type: 'String'
            },
            {
                ColumnName: 'itemID',
                type: 'String'
            },
            {
                ColumnName: 'customFieldValue',
                type: 'String'
            }
        ]
    )
    res.render('admin/reward/ordersView')
}

export async function doGetSuggestions (req: express.Request, res: express.Response) {
    await pagination (
        req,
        res,
        'updatedAt',
        req.prisma.rewardSuggest,
        [
            {
                ColumnName: 'rewardName',
                type: 'String'
            },
            {
                ColumnName: 'username',
                type: 'String'
            },
            {
                ColumnName: 'website',
                type: 'String'
            },
            {
                ColumnName: 'region',
                type: 'String'
            },
            {
                ColumnName: 'description',
                type: 'String'
            }
        ]
    )

    res.render('admin/reward/suggestionsView')
}