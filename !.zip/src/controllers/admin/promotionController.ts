import express from 'express'
import pagination from '../../utils/admin/pagination'

export async function doGetPromotion(req: express.Request, res: express.Response) {

    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.promotionHistory,
        [
            {
                ColumnName: "id",
                type: "Int"
            },
            {
                ColumnName: "promotionName",
                type: "String"
            },
            {
                ColumnName: "username",
                type: "String"
            },
            {
                ColumnName: "points",
                type: "Int"
            }
        ]
    )

    res.render('admin/promotion/logsView')
}