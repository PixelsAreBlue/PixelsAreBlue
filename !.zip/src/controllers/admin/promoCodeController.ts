import express from 'express'
import pagination from '../../utils/admin/pagination'
import { formError } from '../../types/types'

export async function doGetManage (req: express.Request, res: express.Response) {    
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.promoCode,
        [
            {
                ColumnName: "code",
                type: "String"
            },
            {
                ColumnName: "points",
                type: "Int"
            },
            {
                ColumnName: "maxUse",
                type: "Int"
            },
            {
                ColumnName: "isExpired",
                type: "Boolean"
            }
        ]
    )
    res.render('admin/promoCode/manageView')
}

export async function doGetHistory (req: express.Request, res: express.Response) {
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.promoCodeHistory,
        [
            {
                ColumnName: 'code',
                type: 'String'
            },
            {
                ColumnName: 'username',
                type: 'String'
            }
        ]
    )
    res.render('admin/promoCode/historyView')
}

export async function doGetCreate (req: express.Request, res: express.Response) {    
    res.render('admin/promoCode/createView')
}
export async function doPostCreate (req: express.Request, res: express.Response) {
    let formErrors: formError[] = []
    if (!req.body.code || !req.body.code.length) formErrors.push({ fieldName: 'code', message: 'Code must not be empty' })
    if (!Math.abs(req.body.reward)) formErrors.push({ fieldName: 'reward', message: 'Reward is invalid' })
    if (await req.prisma.promoCode.count({ 
        where: {
            code: req.body.code
        }
    }) > 0) {
        formErrors.push({ fieldName: 'code', message: 'Code must be unique' })
    }
    if(formErrors.length) return res.render('admin/promoCode/createView', { formErrors: formErrors })

    await req.prisma.promoCode.create({
        data: {
            code: req.body.code,
            points: Math.abs(req.body.reward),
            maxUse: parseInt(req.body.maxUse) && parseInt(req.body.maxUse) > 0 ? parseInt(req.body.maxUse) : null,
            expiryDate: !isNaN(Date.parse(req.body.expiry)) ? new Date(req.body.expiry) : null
        }
    })

    res.redirect('/admin/promo-code')
}

export async function doGetDeactivate (req: express.Request, res: express.Response) {
    const query = await req.prisma.promoCode.findFirst({
        where: {
            code: req.params.code 
        }
    })
    if (!query) return res.send('Code not exist')

    await req.prisma.promoCode.update({
        where: {
            code: req.params.code 
        },
        data: {
            isExpired: true
        }
    })

    res.redirect('/admin/promo-code')
}