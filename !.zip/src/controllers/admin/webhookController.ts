import express from 'express'

export async function doGetWebhook(req: express.Request, res: express.Response) {
    
    res.render('admin/webhookStatistics', {
        count: {
            inQueue: await req.prisma.webhookQueue.count({
                where: {
                    isSent: false,
                    isError: false
                }
            }),
            error: await req.prisma.webhookQueue.count({
                where: {
                    isError: true
                }
            }),
            sent: await req.prisma.webhookQueue.count({
                where: {
                    isSent: true
                }
            })
        }
    })
}

export async function doPostWebhook (req: express.Request, res: express.Response) {
    if (req.body.action === 'clearQueue') {
        console.log('Clearing Webhook Queue')
        await req.prisma.webhookQueue.deleteMany({
            where: {
                isSent: false,
                isError: false
            }
        })
    }
    res.redirect('/admin/webhook')
}