import express from 'express'
import pagination from '../../utils/admin/pagination'

export async function doGetAuditLogs (req: express.Request, res: express.Response) {    
    await pagination(
        req,
        res,
        'timestamp',
        req.prisma.auditLog,
        [
            {
                ColumnName: "referenceID",
                type: "Int"
            },
            {
                ColumnName: "logLevel",
                type: "Enum",
                Enums: ['debug', 'info', 'warn', 'error', 'fatal']
            },
            {
                ColumnName: "resourceName",
                type: "String"
            },
            {
                ColumnName: "eventName",
                type: "String"
            },
            {
                ColumnName: 'description',
                type: 'String',
            },
            {
                ColumnName: 'actionInfo',
                type: 'String'
            },
            {
                ColumnName: 'actionType',
                type: 'Enum',
                Enums: ['create', 'read', 'update', 'delete']
            },
            {
                ColumnName: 'user',
                type: 'String'
            },
            {
                ColumnName: 'ip',
                type: 'String'
            }
        ]
    )

    res.render('admin/auditLogsView')
}