import express from 'express'
import pagination from '../../utils/admin/pagination'

export async function doGetLogs (req: express.Request, res: express.Response) {
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.offerHistory,
        [
            {
                ColumnName: 'id',
                type: 'Int'
            },
            {
                ColumnName: "provider",
                type: "String"
            },
            {
                ColumnName: "username",
                type: "String"
            },
            {
                ColumnName: "transactionId",
                type: "String"
            },
            {
                ColumnName: "action",
                type: "Enum",
                Enums: ['add', 'reversal']
            },
            {
                ColumnName: "points",
                type: "Int"
            }
        ]
    )
    res.render('admin/offer/logsView')
}

export async function doGetReferralHistory(req: express.Request, res: express.Response) {    
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.referralHistory,
        [
            {
                ColumnName: "referrerUsername",
                type: "String"
            },
            {
                ColumnName: "referredUsername",
                type: "String"
            },
            {
                ColumnName: "commissionPoints",
                type: "Int"
            },
            {
                ColumnName: 'referenceId',
                type: 'Int'
            }
        ]
    )
    res.render('admin/offer/referralHistory')
}
