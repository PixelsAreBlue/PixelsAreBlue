import express from 'express'
import pagination from '../../utils/admin/pagination'

export async function doGetOverView (req: express.Request, res: express.Response) {
    res.render('admin/overview', {
        usersCount: await req.prisma.user.count(),
        offersCount: await req.prisma.offerHistory.count({
            where: {
                createdAt: {
                    gte: new Date(new Date().setDate(new Date().getDate() - 30))
                }
            }
        }),
        Offers: await req.prisma.offerHistory.findMany({
            orderBy:{
                updatedAt: 'desc'
            },
            take: 5
        }),
        system: {
            env: process.env.NODE_ENV || 'Unknown',
            ver: process.version
        }
    })
}

export async function doPostOverview (req: express.Request, res: express.Response) {
    if (req.body.action === 'restart') {
        console.log('Restarting the Server...')
        //if you using PM2, the server will restart automatically
        process.exit()
    }
}

export async function doGetJackpotHistory (req: express.Request, res: express.Response) {
    await pagination(
        req,
        res,
        'updatedAt',
        req.prisma.jackpotHistory,
        [
            {
                ColumnName: "username",
                type: "String"
            },
            {
                ColumnName: "points",
                type: "Int"
            }
        ]
    )
    res.render('admin/jackpotHistoryView')
}