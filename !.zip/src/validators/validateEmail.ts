export default function validateEmail (email: string | null | undefined) {
    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    

    if (!email || !email.length) {
        return 'Email must not be empty'
    }

    if (!re.test(email)) {
        return 'Please provide a valid email address'
    }
    return null
}