export default function validateUsername (username: string | null | undefined) {
    const re = /^[0-9a-zA-Z]+$/

    if (!username || !username.length) {
        return 'Username must not be empty'
    }

    if (!re.test(username)) {
        return 'username must only contain letters and numbers'
    }

    if (username.length > 20) {
        return 'username must be 20 characters or less'
    }

    return null
}