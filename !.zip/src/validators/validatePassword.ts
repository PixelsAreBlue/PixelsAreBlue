export default function validatePassword (password: string | null | undefined) {
    const re = /^[a-zA-Z0-9!@#\$%\^&\*]*$/
    
    if (!password || !password.length) {
        return 'Password must not be empty'
    }

    if (!re.test(password)) {
        return 'Password must only contain letters digits and special characters'
    }

    if (password.length > 30) {
        return 'Password must be 30 characters or less'
    }

    return null
}