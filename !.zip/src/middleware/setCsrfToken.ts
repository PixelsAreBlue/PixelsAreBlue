import express from 'express'

export default async function setCsrfTokenMiddleware (req: express.Request, res: express.Response, next:express.NextFunction) {
    res.locals._csrf =  req.csrfToken()
    next()
}