import express from 'express' 
import { default as config } from '../config.json'

export default async function httpLoggerMiddleware (req: express.Request, res: express.Response, next:express.NextFunction) {
    await req.prisma.webhookQueue.create({
        data: {
            webhookUrl: config.discord.webhooks.httpLog, 
            timestamp: new Date(),
            fields: [
                {
                    name: "HTTP Method",
                    value: req.method || '**Unknown**'
                },
                {
                    name: "Request URL",
                    value: req.url || '**Unknown**'
                }, 
                {
                    name: 'Request Body',
                    value: JSON.stringify(req.body) || '**Unknown**'
                },
                {
                    name: "IP Address",
                    value: req.ip || '**Unknown**'
                },
                {
                    name: 'User Agent',
                    value: req.get('User-Agent') || '**Unknown**'
                },
                {
                    name: 'Session',
                    value: JSON.stringify(req.session) || '**Unknown**'
                },
                {
                    name: 'Referrer',
                    value: req.headers['referrer'] || '**Unknown**'
                },
                {
                    name: 'Accept Language',
                    value: req.headers['accept-language'] || '**Unknown**'
                }
            ]
        }
    })
    next()
}