import express from 'express'
import { default as config } from '../config.json'

export async function setOfferwalls (req: express.Request, res:express.Response, next:express.NextFunction) {
    res.locals.Offerwalls = [
        {
            id: 'wannads',
            title: 'Wannads',
            provider: 'wannads',
            time: '5 - 15 minutes',
            score: 0,
            wallUrl: `https://wall.wannads.com/wall?apiKey=${config.apikeys.wannads.apiKey}&userId=${req.session.loginUser}`,
            embedCode: `<iframe style="width:100%; height:800px; border:0; padding:0; margin:0;" scrolling="yes" "frameborder="0" src="https://wall.wannads.com/wall?apiKey=${config.apikeys.wannads.apiKey}&userId=${req.session.loginUser}"></iframe> `,
            bannerImgUrl: 'https://i.imgur.com/TCBAsmx.png'
        },
        {
            id: 'cpx',
            title: 'CPX Research',
            provider: 'cpxResearch',
            time: '15 minutes',
            score: 0,
            wallUrl: `https://offers.cpx-research.com/index.php?app_id=${config.apikeys.cpxResearch.appId}&ext_user_id=${req.session.loginUser}`,
            embedCode: `<iframe width="100%" frameBorder="0" height="2000px"  src="https://offers.cpx-research.com/index.php?app_id=${config.apikeys.cpxResearch.appId}&ext_user_id=${req.session.loginUser}"></iframe>`,
            bannerImgUrl: 'https://i.imgur.com/QPrfuHv.png'
        },
        {
            id: 'kiwiwall',
            title: 'Kiwiwall',
            provider: 'kiwiwall',
            time: '5 - 30 minutes',
            score: 0,
            wallUrl: `https://www.kiwiwall.com/wall/${config.apikeys.kiwiwall.wallId}/${req.session.loginUser}`,
            embedCode: `<iframe width="750" height="1400" src="https://www.kiwiwall.com/wall/${config.apikeys.kiwiwall.wallId}/${req.session.loginUser}" frameborder="0" allowfullscreen></iframe>`,
            bannerImgUrl: 'https://i.imgur.com/cgn1a2g.png'
        },
        {
            id: 'mediumpath',
            title: 'MediumPath',
            provider: 'mediumPath',
            time: '5 - 30 minutes',
            score: 0,
            wallUrl: `https://www.mediumpath.com/api/offerwall/?key=${config.apikeys.mediumpath.apiKey}&user_id=${req.session.loginUser}`,
            embedCode: `<iframe style="width:100%;height:800px;border:0;padding:0;margin:0;" scrolling="yes" frameborder="0" src="https://www.mediumpath.com/api/offerwall/?key=${config.apikeys.mediumpath.apiKey}&user_id=${req.session.loginUser}"></iframe>`,
            bannerImgUrl: 'https://i.imgur.com/5V1ikHN.png'
        },
        {
            id: 'bitlabs',
            title: 'Bitlabs',
            provider: 'bitlabs',
            time: '15 minutes',
            score: 0,
            wallUrl: `https://web.bitlabs.ai/?uid=${req.session.loginUser}&token=${config.apikeys.bitlabs.appToken}`,
            embedCode: `<iframe style="width:100%;height:800px;" scrolling="yes" frameborder="0" src="https://web.bitlabs.ai/?uid=${req.session.loginUser}&token=${config.apikeys.bitlabs.appToken}"></iframe>`,
            bannerImgUrl: 'https://i.imgur.com/SdkNqvu.png'
        },
        {
            id: 'wannads-survey',
            title: 'Wannads Survey',
            provider: 'wannads',
            time: '15 minutes',
            score: 0,
            wallUrl: `https://surveywall.wannads.com/?apiKey=${config.apikeys.wannads.apiKey}&userId=${req.session.loginUser}`,
            embedCode: `<iframe style="width:100%; height:800px; border:0; padding:0; margin:0;" scrolling="yes" "frameborder="0" src="https://surveywall.wannads.com?apiKey=${config.apikeys.wannads.apiKey}&userId=${req.session.loginUser}"></iframe>`,
            bannerImgUrl: 'https://i.imgur.com/Dm3YVou.png'
        },
        {
            id: 'lootably',
            title: 'Lootably',
            provider: 'lootably',
            time: '15 minutes',
            score: 0,
            wallUrl: `https://wall.lootably.com/?placementID=${config.apikeys.lootably.placementID}&sid=${req.session.loginUser}`,
            embedCode: `<iframe title="Lootably Offer Wall" src="https://wall.lootably.com/?placementID=${config.apikeys.lootably.placementID}&sid=${req.session.loginUser}" style="width: 100%; height: 800px;" />`,
            bannerImgUrl: 'https://i.imgur.com/lt7qUJM.png'
        },
        {
            id: 'opinion-capital',
            time: '15 minutes',
            provider: 'opinionCapital',
            title: 'Opinion Capital',
            score: 0,
            wallUrl: `https://wall.opinioncapital.com/panel/${config.apikeys.opinionCapital.panelNumber}/${req.session.loginUser}`,
            embedCode: `<iframe src="https://wall.opinioncapital.com/panel/${config.apikeys.opinionCapital.panelNumber}/${req.session.loginUser}" style="width: 100%; height: 800px;" />`,
            bannerImgUrl: 'https://i.imgur.com/FRvNgHo.png'
        }
    ]
    res.locals.videoWalls = [
        {
            id: 'loottv',
            title: 'Loot.tv',
            wallUrl: `https://api.lootably.com/api/offerwall/redirect/offer/101-999?placementID=${config.apikeys.lootably.placementID}&rawPublisherUserID=${req.session.loginUser}`,
            bannerImgUrl: 'https://i.imgur.com/qX9kAzW.png'
        }
    ]


    const byWall: any = await global.prisma.$queryRaw`SELECT "provider", SUM(points) as points FROM "OfferHistory" WHERE "createdAt" > now() - interval '3 month' GROUP BY "provider"`
    const total: any = await global.prisma.$queryRaw`SELECT SUM(points) as points FROM "OfferHistory" WHERE "createdAt" > now() - interval '3 month'`

    for (let offerwall of res.locals.Offerwalls) {
        const wallFilter = byWall.filter(function (wall: any) {
            return wall.provider === offerwall.provider
        })

        if (wallFilter.length) {

            const wallPoints = wallFilter[0].points
            const totalPoints = total[0].points

            offerwall.score = Math.floor(wallPoints / totalPoints * 100)
        }
    }

    res.locals.Offerwalls.sort(function (a: any, b:any) {
        if (a.score > b.score) return -1
        if (a.score < b.score) return 1
    })

    next()
}