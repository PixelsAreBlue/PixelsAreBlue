import express from 'express'
import fs from 'fs'
import { fileURLToPath } from 'url'
import path from 'path'

export default function localeSwitcher (req: express.Request, res:express.Response, next:express.NextFunction) {
    const localizable = ['en', 'ja', 'lt']

    if (req.query.hl && req.query.hl.length && localizable.includes(req.query.hl as string)) {
        req.session.lang = req.query.hl
    } else if (!req.session.lang && req.acceptsLanguages(localizable)) {
        req.session.lang = req.acceptsLanguages(localizable)
    }

    const currentDir = fileURLToPath(path.dirname(import.meta.url))
    const data = fs.readFileSync(`${currentDir}/../locales/${req.session.lang || 'en'}.json`).toString()

    res.locals.locales = JSON.parse(data)

    next()
}