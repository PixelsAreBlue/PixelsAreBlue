import express from 'express'
import { PrismaClient } from '@prisma/client'
const { PrismaClient } = prisma

declare module 'express-session' {
    interface SessionData {
        [key: string]: any
    }
}
interface formError{
    fieldName: string,
    message: string
}

declare global {
    namespace Express {
        export interface Request {
            prisma: PrismaClient
        }
    }
    var prisma: PrismaClient
}