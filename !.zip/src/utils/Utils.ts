import { createServer } from 'net'

export function isPortTaken (port: number) {
    return new Promise((resolve, reject) => {
        const tester = createServer()
        .once('error', function (err: any) {
            if (err.code != 'EADDRINUSE') return reject(err)
            return resolve(true)
        })
        .once('listening', function() {
            tester.once('close', function() { resolve(false) })
            .close()
        })
        .listen(port)
    })
}