import axios from 'axios'
import config from '../config.json'

export default class RecaptchaClient {
    public static async verifyRecaptchaToken (token:string):Promise<boolean> {
        const res = await axios.post('https://www.google.com/recaptcha/api/siteverify', new URLSearchParams({
            secret: config.apikeys.recaptcha.secret,
            response: token
        }).toString(), {
            headers: { 
                "Content-Type": "application/x-www-form-urlencoded"
            }
        })
        if(res.data.success) return true
        else return false
    }
}