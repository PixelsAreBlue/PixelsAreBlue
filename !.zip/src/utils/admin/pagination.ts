import express from 'express'

interface PrismaColumns {
    ColumnName: string,
    type: string //value must be Int or Boolean or String
    Enums?: string[]
}

export default async function pagination (
    req: express.Request,
    res: express.Response,
    sortBy:any = 'updatedAt',
    prismaModel: any,
    prismaColumns: PrismaColumns[] = [] //field names that allow to search
){
    const startTime = performance.now()

    let itemsPerPage
    if(parseFloat(req.query.itemsPerPage as string)) itemsPerPage = parseFloat(req.query.itemsPerPage as string)
    else itemsPerPage = 10

    const lastPage = Math.floor(await prismaModel.count() / itemsPerPage)

    let page
    if(parseFloat(req.query.page as string)) page = parseFloat(req.query.page as string)
    else page = 0

    let queryFilter: any = {}
    let searchFilter: any = []

    if(req.query.search) {

        const search = req.query.search as string
        const parseStr = [...search.matchAll(/(?<=^|\s)(.[a-zA-Z0-9@_.-]*):(.[a-zA-Z0-9@_.-]*)(?=$|\s)/g)]
        
        const searchStr = search.replace(/(?<=^|\s)(.[a-zA-Z0-9@_.-]*):(.[a-zA-Z0-9@_.-]*)(?=$|\s)/g, '')

        parseStr.forEach( function (filter) {
            const column = prismaColumns.filter(c => c.ColumnName === filter[1])[0]

            let value: string | number | boolean | undefined

            if (!column) return
            else if (column.type === "Int") value = parseInt(filter[2])
            else if (column.type === "Boolean") value = filter[2] === 'true' ? true : false
            else if (column.type === "Enum" && column.Enums!.includes(filter[2])) value = filter[2]
            else if (column.type === "String") value = filter[2]

            queryFilter[filter[1]] = value 
        })
        if (searchStr.length){
            prismaColumns.forEach( function (column) {
                if (column.type === "String") {
                    
                    searchFilter.push({
                        [column.ColumnName]: {
                            search: searchStr
                        }
                    })
                }
            })
        }
    }


    let baseQuery:any = {
        where: {
            ...queryFilter
        }
    }
    if (Object.keys(searchFilter).length) {
        baseQuery.where.OR = searchFilter
    }

    const pageItems = await prismaModel.findMany({
        ...baseQuery,
        skip: itemsPerPage * page,
        take: itemsPerPage,
        orderBy: {
            [sortBy]: 'desc'
        }
    })


    const resultsTotal = await prismaModel.count({
        ...baseQuery
    })


    res.locals.pagination = {
        pageItems: pageItems,
        lastPage: lastPage,
        totalResultsCount: resultsTotal,
        currentPage: page,
        queryTime: performance.now() - startTime
    }

}
