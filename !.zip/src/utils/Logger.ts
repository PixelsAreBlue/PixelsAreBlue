import chalk from 'chalk'
import moment from 'moment'

class Logger {
    static log (content:any, type:string = "log") {
        const timestamp = `[${moment().format("YYYY-MM-DD HH:mm:ss")}]:`;
        switch (type) {
            case "log": {
                return console.log(`${timestamp} ${chalk.bgBlue(type.toUpperCase())} ${content} `)
            }
            case "warn": {
                return console.log(`${timestamp} ${chalk.black.bgYellow(type.toUpperCase())} ${content} `)
            }
            case "error": {
                return console.log(`${timestamp} ${chalk.bgRed(type.toUpperCase())} ${content} `)
            }
            case "debug": {
                return console.log(`${timestamp} ${chalk.green(type.toUpperCase())} ${content} `)
            }
            case "cmd": {
                return console.log(`${timestamp} ${chalk.black.bgWhite(type.toUpperCase())} ${content}`)
            }
            case "ready": {
                return console.log(`${timestamp} ${chalk.black.bgGreen(type.toUpperCase())} ${content}`)
            }
            default: throw new TypeError("Logger type must be either warn, debug, log, ready, cmd or error.")
        } 
    }
    
    static error (content:any) {
        return this.log(content, "error")
    }
    
    static warn (content:any) {
        return this.log(content, "warn")
    }
    
    static debug (content:any) {
        return this.log(content, "debug")
    } 
    
    static cmd (content:any) {
        return this.log(content, "cmd")
    } 
    static ready (content:any) {
        return this.log(content, "ready")
    }
}

export default Logger